import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/lib/supabaseClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, FileText, Calendar, Star, ArrowRight } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

interface Redacao {
  id: string;
  titulo: string;
  created_at: string;
  correcao: {
    id: string;
    nota_total: number;
  } | null;
}

const History = () => {
  const navigate = useNavigate();
  const [redacoes, setRedacoes] = useState<Redacao[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchRedacoes();
  }, []);

  const fetchRedacoes = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error("Usuário não autenticado");
      }

      const { data, error } = await supabase
        .from("redacoes")
        .select(`
          id,
          titulo,
          created_at,
          correcoes (
            id,
            nota_total
          )
        `)
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (error) throw error;

      // Transformar os dados para o formato desejado
      const redacoesFormatadas = data.map(redacao => ({
        id: redacao.id,
        titulo: redacao.titulo,
        created_at: redacao.created_at,
        correcao: redacao.correcoes?.[0] || null
      }));

      setRedacoes(redacoesFormatadas);
    } catch (error: any) {
      setError(error.message);
      toast({
        title: "Erro ao carregar histórico",
        description: "Não foi possível carregar seu histórico de redações. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-nota-blue" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Alert variant="destructive" className="max-w-md">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Histórico de Redações</h1>
          <Button
            onClick={() => navigate("/new")}
            className="bg-nota-blue hover:bg-nota-blue-700"
          >
            Nova Redação
          </Button>
        </div>

        {redacoes.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhuma redação encontrada</h3>
              <p className="text-gray-500 mb-6">
                Você ainda não enviou nenhuma redação para correção.
              </p>
              <Button
                onClick={() => navigate("/new")}
                className="bg-nota-blue hover:bg-nota-blue-700"
              >
                Enviar primeira redação
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {redacoes.map((redacao) => (
              <Card key={redacao.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <CardTitle className="text-lg font-semibold">
                        {redacao.titulo}
                      </CardTitle>
                      <div className="flex items-center text-sm text-gray-500">
                        <Calendar className="h-4 w-4 mr-1" />
                        {formatDate(redacao.created_at)}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      {redacao.correcao ? (
                        <div className="flex items-center text-nota-blue">
                          <Star className="h-5 w-5 mr-1" />
                          <span className="font-semibold">
                            {redacao.correcao.nota_total.toFixed(1)}
                          </span>
                        </div>
                      ) : (
                        <span className="text-sm text-gray-500">Em correção</span>
                      )}
                      
                      <Button
                        variant="ghost"
                        onClick={() => navigate(`/resultado/${redacao.correcao?.id}`)}
                        className="flex items-center gap-2"
                      >
                        Ver resultado
                        <ArrowRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default History;
