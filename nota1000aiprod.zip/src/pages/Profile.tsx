
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { toast } from '@/components/ui/use-toast';

// Mock user data
const user = {
  name: 'José Silva',
  email: 'jose.silva@exemplo.com',
  institution: 'Escola Estadual Prof. Carlos Martins',
  plan: 'Básico',
};

const Profile = () => {
  const [showPlagiarismAlerts, setShowPlagiarismAlerts] = useState(true);
  const [autoExport, setAutoExport] = useState(false);
  const [language, setLanguage] = useState('pt-BR');
  
  const handleSaveChanges = () => {
    toast({
      title: "Alterações salvas",
      description: "Suas preferências foram atualizadas com sucesso.",
    });
  };
  
  const handleDeleteAccount = () => {
    // In a real app, this would handle account deletion
    console.log('Account deletion requested');
  };
  
  return (
    <div className="container max-w-4xl py-8 animate-fade-in">
      <h1 className="text-3xl font-bold mb-2">Perfil e Configurações</h1>
      <p className="text-gray-600 mb-6">Gerencie suas informações e preferências</p>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Informações Pessoais</CardTitle>
              <CardDescription>
                Atualize seus dados cadastrais
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nome completo</Label>
                  <Input id="name" defaultValue={user.name} />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" defaultValue={user.email} />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="institution">Instituição (opcional)</Label>
                  <Input id="institution" defaultValue={user.institution} />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="current-password">Senha atual</Label>
                  <Input id="current-password" type="password" placeholder="Digite para alterar senha" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="new-password">Nova senha</Label>
                  <Input id="new-password" type="password" placeholder="Nova senha" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="confirm-password">Confirmar nova senha</Label>
                  <Input id="confirm-password" type="password" placeholder="Confirmar nova senha" />
                </div>
              </form>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSaveChanges} className="bg-nota-blue hover:bg-nota-blue-700">
                Salvar alterações
              </Button>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Preferências de Correção</CardTitle>
              <CardDescription>
                Configure como as redações serão corrigidas
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="plagiarism">Alertas de plágio</Label>
                  <p className="text-sm text-muted-foreground">
                    Receba alertas quando detectarmos conteúdo semelhante a outras fontes
                  </p>
                </div>
                <Switch 
                  id="plagiarism" 
                  checked={showPlagiarismAlerts}
                  onCheckedChange={setShowPlagiarismAlerts}
                />
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="auto-export">Exportação automática</Label>
                  <p className="text-sm text-muted-foreground">
                    Gerar automaticamente PDF após a correção
                  </p>
                </div>
                <Switch 
                  id="auto-export" 
                  checked={autoExport}
                  onCheckedChange={setAutoExport}
                />
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <Label htmlFor="language">Idioma da correção</Label>
                <select 
                  id="language"
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <option value="pt-BR">Português (Brasil)</option>
                  <option value="en-US">English (United States)</option>
                  <option value="es">Español</option>
                </select>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSaveChanges} className="bg-nota-blue hover:bg-nota-blue-700">
                Salvar preferências
              </Button>
            </CardFooter>
          </Card>
        </div>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Seu Plano</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="font-semibold text-lg">{user.plan}</div>
                <p className="text-sm text-gray-600 mt-1">10 correções/mês</p>
              </div>
              <div className="text-sm text-gray-600">
                <div className="mb-2">Recursos disponíveis:</div>
                <ul className="space-y-1">
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    <span>Correção em até 5 minutos</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    <span>Feedback detalhado</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    <span>Exportação em PDF</span>
                  </li>
                </ul>
              </div>
              <Button variant="outline" className="w-full">
                Atualizar plano
              </Button>
            </CardContent>
          </Card>
          
          <Card className="border-red-100">
            <CardHeader>
              <CardTitle className="text-red-600">Zona de Perigo</CardTitle>
              <CardDescription>
                Ações que não podem ser desfeitas
              </CardDescription>
            </CardHeader>
            <CardContent>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" className="w-full">
                    Excluir minha conta
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Você tem certeza?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Esta ação não pode ser desfeita. Isso excluirá permanentemente sua conta 
                      e removerá seus dados de nossos servidores.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDeleteAccount} className="bg-red-600 hover:bg-red-700">
                      Sim, excluir minha conta
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Profile;
