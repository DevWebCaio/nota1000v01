import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { Loader2 } from 'lucide-react';

export default function ProtectedProfessorRoute({ children }: { children: React.ReactNode }) {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [permitido, setPermitido] = useState(false);

  useEffect(() => {
    const verificarPermissao = async () => {
      try {
        const { data: authData } = await supabase.auth.getUser();
        const userId = authData.user?.id;

        if (!userId) {
          navigate('/login');
          return;
        }

        const { data: usuario, error } = await supabase
          .from('usuarios')
          .select('tipo')
          .eq('id', userId)
          .single();

        if (error) throw error;

        if (usuario?.tipo === 'professor') {
          setPermitido(true);
        } else {
          navigate('/unauthorized');
        }
      } catch (error) {
        console.error('Erro ao verificar permissão:', error);
        navigate('/unauthorized');
      } finally {
        setLoading(false);
      }
    };

    verificarPermissao();
  }, [navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-nota-blue" />
      </div>
    );
  }

  return <>{permitido && children}</>;
} 