
import { Link } from "react-router-dom";
import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { FileText, ArrowLeft } from "lucide-react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-white to-gray-50 p-6">
      <div className="text-center max-w-md animate-fade-in">
        <FileText className="h-20 w-20 text-nota-blue mx-auto mb-6 opacity-50" />
        <h1 className="text-7xl font-bold text-nota-blue mb-6">404</h1>
        <p className="text-2xl font-semibold text-gray-800 mb-4">Oops! Página não encontrada</p>
        <p className="text-gray-600 mb-8">
          A página que você está procurando não existe ou foi movida.
        </p>
        <Button 
          asChild 
          className="bg-nota-blue hover:bg-nota-blue-700 transition-all duration-300 shadow-md hover:shadow-lg py-6 px-8 text-base font-medium group"
        >
          <Link to="/" className="flex items-center">
            <ArrowLeft className="mr-2 h-5 w-5 transition-transform group-hover:-translate-x-1" />
            Voltar para a página inicial
          </Link>
        </Button>
      </div>
    </div>
  );
};

export default NotFound;
