import { createBrowserRouter } from "react-router-dom";
import Landing from "@/pages/Landing";
import Login from "@/pages/Login";
import Signup from "@/pages/Signup";
import NewEssay from "@/pages/NewEssay";
import EssayResult from "@/pages/EssayResult";
import History from "@/pages/History";
import Profile from "@/pages/Profile";
import Settings from "@/pages/Settings";
import ForgotPassword from "@/pages/ForgotPassword";
import Plans from "@/pages/Plans";
import NotFound from "@/pages/NotFound";
import Logout from "@/pages/Logout";
import Unauthorized from "@/pages/Unauthorized";
import PainelProfessor from "@/pages/PainelProfessor";
import AdminDashboard from "@/pages/AdminDashboard";
import StudentProgress from "@/pages/StudentProgress";
import ProtectedRoute from "@/components/auth/ProtectedRoute";
import RoleBasedRoute from "@/components/auth/RoleBasedRoute";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Landing />,
  },
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/register",
    element: <Signup />,
  },
  {
    path: "/forgot-password",
    element: <ForgotPassword />,
  },
  {
    path: "/plans",
    element: <Plans />,
  },
  {
    path: "/unauthorized",
    element: <Unauthorized />,
  },
  {
    path: "/new",
    element: (
      <RoleBasedRoute allowedRoles={["aluno"]}>
        <NewEssay />
      </RoleBasedRoute>
    ),
  },
  {
    path: "/resultado/:correcaoId",
    element: (
      <RoleBasedRoute allowedRoles={["aluno", "professor"]}>
        <EssayResult />
      </RoleBasedRoute>
    ),
  },
  {
    path: "/history",
    element: (
      <RoleBasedRoute allowedRoles={["aluno", "professor"]}>
        <History />
      </RoleBasedRoute>
    ),
  },
  {
    path: "/profile",
    element: (
      <RoleBasedRoute allowedRoles={["aluno", "professor"]}>
        <Profile />
      </RoleBasedRoute>
    ),
  },
  {
    path: "/settings",
    element: (
      <RoleBasedRoute allowedRoles={["aluno", "professor"]}>
        <Settings />
      </RoleBasedRoute>
    ),
  },
  {
    path: "/progresso",
    element: (
      <RoleBasedRoute allowedRoles={["aluno"]}>
        <StudentProgress />
      </RoleBasedRoute>
    ),
  },
  {
    path: "/painel-professor",
    element: (
      <RoleBasedRoute allowedRoles={["professor"]}>
        <PainelProfessor />
      </RoleBasedRoute>
    ),
  },
  {
    path: "/admin",
    element: (
      <RoleBasedRoute allowedRoles={["admin"]}>
        <AdminDashboard />
      </RoleBasedRoute>
    ),
  },
  {
    path: "/logout",
    element: <Logout />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
]);

export default router; 