
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { 
  Home, 
  FileText, 
  History, 
  User, 
  Settings, 
  Package, 
  LogOut,
  ChevronLeft,
  ChevronRight
} from "lucide-react";

const Sidebar = () => {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();
  
  const isActive = (path: string) => location.pathname === path;
  
  const menuItems = [
    { path: '/', icon: <Home className="h-5 w-5" />, label: 'Dashboard' },
    { path: '/new', icon: <FileText className="h-5 w-5" />, label: 'Nova Redação' },
    { path: '/history', icon: <History className="h-5 w-5" />, label: 'Histórico' },
    { path: '/plans', icon: <Package className="h-5 w-5" />, label: 'Planos' },
    { path: '/profile', icon: <User className="h-5 w-5" />, label: 'Perfil' },
    { path: '/settings', icon: <Settings className="h-5 w-5" />, label: 'Configurações' },
  ];
  
  return (
    <>
      {/* Desktop Sidebar */}
      <aside
        className={cn(
          "fixed left-0 top-0 z-20 h-full bg-white border-r border-gray-200 transition-all duration-300 hidden md:flex flex-col",
          collapsed ? "w-16" : "w-64"
        )}
      >
        <div className="flex items-center h-16 px-4 border-b border-gray-200">
          {!collapsed && (
            <Link to="/" className="flex items-center">
              <FileText className="h-6 w-6 text-nota-blue" />
              <span className="ml-2 text-lg font-bold text-nota-blue">Nota1000.AI</span>
            </Link>
          )}
          {collapsed && (
            <Link to="/" className="flex items-center justify-center w-full">
              <FileText className="h-6 w-6 text-nota-blue" />
            </Link>
          )}
        </div>
        
        <div className="flex flex-col flex-1 py-4 overflow-y-auto">
          <div className="px-3 py-2">
            {!collapsed && <h3 className="px-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Menu</h3>}
            <nav className="mt-2 space-y-1">
              {menuItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={cn(
                    "flex items-center px-3 py-2 rounded-md transition-colors",
                    isActive(item.path)
                      ? "bg-nota-blue text-white"
                      : "text-gray-700 hover:bg-gray-100"
                  )}
                >
                  <div className="flex items-center">
                    <span className={cn(isActive(item.path) ? "text-white" : "text-gray-500")}>
                      {item.icon}
                    </span>
                    {!collapsed && <span className="ml-3 text-sm font-medium">{item.label}</span>}
                  </div>
                </Link>
              ))}
            </nav>
          </div>
        </div>
        
        <div className="p-4 border-t border-gray-200">
          <Link
            to="/logout"
            className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-red-600 hover:bg-red-50 transition-colors"
          >
            <LogOut className="h-5 w-5" />
            {!collapsed && <span className="ml-3">Sair</span>}
          </Link>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setCollapsed(!collapsed)}
            className="mt-4 w-full flex justify-center"
          >
            {collapsed ? <ChevronRight className="h-5 w-5" /> : <ChevronLeft className="h-5 w-5" />}
          </Button>
        </div>
      </aside>
      
      {/* Mobile Bottom Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-20 bg-white border-t border-gray-200">
        <div className="grid grid-cols-5 h-16">
          {menuItems.slice(0, 5).map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "flex flex-col items-center justify-center",
                isActive(item.path)
                  ? "text-nota-blue"
                  : "text-gray-600 hover:text-nota-blue"
              )}
            >
              <span className={cn(isActive(item.path) ? "text-nota-blue" : "text-gray-500")}>
                {item.icon}
              </span>
              <span className="text-xs mt-1">{item.label.split(' ')[0]}</span>
            </Link>
          ))}
        </div>
      </div>
      
      {/* Content spacing - for desktop sidebar */}
      <div className={cn("hidden md:block", collapsed ? "ml-16" : "ml-64")}></div>
      
      {/* Content spacing - for mobile bottom nav */}
      <div className="md:hidden mb-16"></div>
    </>
  );
};

export default Sidebar;
