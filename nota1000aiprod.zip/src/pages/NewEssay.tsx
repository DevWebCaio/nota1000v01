import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Upload, FileText, CheckCircle, AlertCircle, Loader2, ArrowLeft } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { useNavigate } from 'react-router-dom';

const NewEssay = () => {
  const navigate = useNavigate();
  const [carregando, setCarregando] = useState(false);
  const [titulo, setTitulo] = useState("");
  const [conteudo, setConteudo] = useState("");
  const [modelo, setModelo] = useState("ENEM");
  const [isSpellcheckEnabled, setIsSpellcheckEnabled] = useState(true);
  const [isPlagiarismDetectionEnabled, setIsPlagiarismDetectionEnabled] = useState(true);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const { toast } = useToast();
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setUploadedFile(e.target.files[0]);
      
      toast({
        title: "Arquivo carregado",
        description: `${e.target.files[0].name} foi enviado com sucesso.`,
      });
    }
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error("Usuário não autenticado");
      }

      // 1. Salvar a redação
      const { data: redacaoData, error: redacaoError } = await supabase
        .from("redacoes")
        .insert([
          {
            user_id: user.id,
            titulo,
            conteudo,
          }
        ])
        .select()
        .single();

      if (redacaoError) throw redacaoError;

      // 2. Simular correção (em produção, isso seria feito por um serviço de IA)
      const correcao = {
        redacao_id: redacaoData.id,
        nota_total: Math.floor(Math.random() * 200) + 800, // Simulação de nota entre 800 e 1000
        competencias: {
          "Competência 1": {
            nota: Math.floor(Math.random() * 200) + 800,
            feedback: "Feedback simulado para competência 1"
          },
          "Competência 2": {
            nota: Math.floor(Math.random() * 200) + 800,
            feedback: "Feedback simulado para competência 2"
          },
          "Competência 3": {
            nota: Math.floor(Math.random() * 200) + 800,
            feedback: "Feedback simulado para competência 3"
          },
          "Competência 4": {
            nota: Math.floor(Math.random() * 200) + 800,
            feedback: "Feedback simulado para competência 4"
          },
          "Competência 5": {
            nota: Math.floor(Math.random() * 200) + 800,
            feedback: "Feedback simulado para competência 5"
          }
        },
        feedback_geral: "Feedback geral simulado para a redação."
      };

      // 3. Salvar a correção
      const { data: correcaoData, error: correcaoError } = await supabase
        .from("correcoes")
        .insert([correcao])
        .select()
        .single();

      if (correcaoError) throw correcaoError;

      toast({
        title: "Redação enviada",
        description: "Sua redação foi enviada e corrigida com sucesso!",
      });

      // 4. Redirecionar para o resultado
      navigate(`/resultado/${correcaoData.id}`);
    } catch (error: any) {
      setError(error.message);
      toast({
        title: "Erro ao enviar redação",
        description: "Não foi possível enviar sua redação. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            onClick={() => navigate(-1)}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Voltar
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-bold">Nova Redação</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="titulo">Título</Label>
                <Input
                  id="titulo"
                  value={titulo}
                  onChange={(e) => setTitulo(e.target.value)}
                  placeholder="Digite o título da sua redação"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="conteudo">Conteúdo</Label>
                <Textarea
                  id="conteudo"
                  value={conteudo}
                  onChange={(e) => setConteudo(e.target.value)}
                  placeholder="Digite o conteúdo da sua redação"
                  className="min-h-[400px]"
                  required
                />
              </div>

              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <Button
                type="submit"
                className="w-full bg-nota-blue hover:bg-nota-blue-700"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Enviando...
                  </>
                ) : (
                  "Enviar para correção"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default NewEssay;
