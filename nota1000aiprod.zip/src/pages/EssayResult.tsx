import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/lib/supabase";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, ArrowLeft, MessageSquare } from "lucide-react";
import { toast } from "@/components/ui/use-toast";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface Comentario {
  id: string;
  mensagem: string;
  created_at: string;
  professor: {
    nome: string;
    avatar_url: string;
  };
}

interface Correcao {
  id: string;
  nota_total: number;
  nota_c1: number;
  nota_c2: number;
  nota_c3: number;
  nota_c4: number;
  nota_c5: number;
  feedback: string;
  ajuste_humano: boolean;
  redacao: {
    titulo: string;
    texto: string;
    created_at: string;
  };
  created_at: string;
}

const EssayResult = () => {
  const navigate = useNavigate();
  const { correcaoId } = useParams();
  const [correcao, setCorrecao] = useState<Correcao | null>(null);
  const [comentarios, setComentarios] = useState<Comentario[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [novoComentario, setNovoComentario] = useState("");
  const [userRole, setUserRole] = useState<string | null>(null);

  useEffect(() => {
    fetchData();
  }, [correcaoId]);

  const fetchData = async () => {
    if (!correcaoId) {
      setError("ID da correção não fornecido");
      return;
    }

    try {
      setIsLoading(true);

      // Verificar papel do usuário
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Usuário não autenticado");

      const { data: userData, error: userError } = await supabase
        .from("usuarios")
        .select("tipo")
        .eq("id", user.id)
        .single();

      if (userError) throw userError;
      setUserRole(userData.tipo);

      // Buscar correção
      const { data: correcaoData, error: correcaoError } = await supabase
        .from("correcoes")
        .select(`
          id,
          nota_total,
          nota_c1,
          nota_c2,
          nota_c3,
          nota_c4,
          nota_c5,
          feedback,
          ajuste_humano,
          created_at,
          redacao:redacoes (
            titulo,
            texto,
            created_at
          )
        `)
        .eq("id", correcaoId)
        .single();

      if (correcaoError) throw correcaoError;
      
      // Transformar os dados para o formato correto
      const correcaoFormatada: Correcao = {
        ...correcaoData,
        redacao: correcaoData.redacao[0]
      };
      
      setCorrecao(correcaoFormatada);

      // Buscar comentários
      const { data: comentariosData, error: comentariosError } = await supabase
        .from("comentarios")
        .select(`
          id,
          mensagem,
          created_at,
          professor:usuarios (
            nome,
            avatar_url
          )
        `)
        .eq("correcao_id", correcaoId)
        .order("created_at", { ascending: false });

      if (comentariosError) throw comentariosError;
      setComentarios(comentariosData.map((c: any) => ({
        ...c,
        professor: c.professor[0]
      })) as Comentario[]);

    } catch (error: any) {
      setError(error.message);
      toast({
        title: "Erro ao carregar dados",
        description: "Não foi possível carregar os dados da correção.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleEnviarComentario = async () => {
    if (!novoComentario.trim()) return;

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Usuário não autenticado");

      const { error } = await supabase
        .from("comentarios")
        .insert({
          correcao_id: correcaoId,
          professor_id: user.id,
          mensagem: novoComentario
        });

      if (error) throw error;

      toast({
        title: "Comentário enviado",
        description: "Seu comentário foi enviado com sucesso.",
      });

      setNovoComentario("");
      fetchData();
    } catch (error: any) {
      toast({
        title: "Erro ao enviar comentário",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-nota-blue" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            onClick={() => navigate(-1)}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Voltar
          </Button>
          <h1 className="text-2xl font-bold">Resultado da Redação</h1>
        </div>

        {error ? (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        ) : correcao ? (
          <div className="grid gap-6">
            {/* Informações da Redação */}
            <Card>
              <CardHeader>
                <CardTitle>{correcao.redacao.titulo}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose max-w-none">
                  <p className="whitespace-pre-wrap">{correcao.redacao.texto}</p>
                </div>
              </CardContent>
            </Card>

            {/* Notas */}
            <Card>
              <CardHeader>
                <CardTitle>Notas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Competência 1</p>
                    <p className="text-lg font-semibold">{correcao.nota_c1}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Competência 2</p>
                    <p className="text-lg font-semibold">{correcao.nota_c2}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Competência 3</p>
                    <p className="text-lg font-semibold">{correcao.nota_c3}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Competência 4</p>
                    <p className="text-lg font-semibold">{correcao.nota_c4}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Competência 5</p>
                    <p className="text-lg font-semibold">{correcao.nota_c5}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Nota Total</p>
                    <p className="text-lg font-semibold text-nota-blue">
                      {correcao.nota_total.toFixed(1)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Feedback */}
            <Card>
              <CardHeader>
                <CardTitle>Feedback</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose max-w-none">
                  <p className="whitespace-pre-wrap">{correcao.feedback}</p>
                </div>
              </CardContent>
            </Card>

            {/* Comentários */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  Comentários
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Lista de Comentários */}
                  {comentarios.map((comentario) => (
                    <div key={comentario.id} className="flex gap-4">
                      <Avatar>
                        <AvatarImage src={comentario.professor.avatar_url} />
                        <AvatarFallback>
                          {comentario.professor.nome.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2">
                          <p className="font-medium">{comentario.professor.nome}</p>
                          <p className="text-sm text-gray-500">
                            {new Date(comentario.created_at).toLocaleDateString()}
                          </p>
                        </div>
                        <p className="text-gray-700">{comentario.mensagem}</p>
                      </div>
                    </div>
                  ))}

                  {/* Formulário de Novo Comentário */}
                  {userRole === "professor" && (
                    <div className="space-y-4">
                      <Textarea
                        placeholder="Digite seu comentário..."
                        value={novoComentario}
                        onChange={(e) => setNovoComentario(e.target.value)}
                        rows={3}
                      />
                      <Button onClick={handleEnviarComentario}>
                        Enviar Comentário
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <Alert>
            <AlertDescription>
              Redação não encontrada ou você não tem permissão para acessá-la.
            </AlertDescription>
          </Alert>
        )}
      </div>
    </div>
  );
};

export default EssayResult;
