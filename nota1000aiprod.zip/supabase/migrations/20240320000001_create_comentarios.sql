-- Create comentarios table
CREATE TABLE comentarios (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  correcao_id UUID REFERENCES correcoes(id) ON DELETE CASCADE,
  professor_id UUID REFERENCES usuarios(id) ON DELETE CASCADE,
  mensagem TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Create RLS policies
ALTER TABLE comentarios ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Professores podem ver seus próprios comentários"
  ON comentarios FOR SELECT
  USING (auth.uid() = professor_id);

CREATE POLICY "Alunos podem ver comentários em suas redações"
  ON comentarios FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM correcoes c
      JOIN redacoes r ON c.redacao_id = r.id
      WHERE c.id = comentarios.correcao_id
      AND r.usuario_id = auth.uid()
    )
  );

CREATE POLICY "Professores podem criar comentários"
  ON comentarios FOR INSERT
  WITH CHECK (auth.uid() = professor_id);

CREATE POLICY "Professores podem atualizar seus próprios comentários"
  ON comentarios FOR UPDATE
  USING (auth.uid() = professor_id);

CREATE POLICY "Professores podem deletar seus próprios comentários"
  ON comentarios FOR DELETE
  USING (auth.uid() = professor_id);

-- Create function to update updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = timezone('utc'::text, now());
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for updated_at
CREATE TRIGGER update_comentarios_updated_at
  BEFORE UPDATE ON comentarios
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column(); 