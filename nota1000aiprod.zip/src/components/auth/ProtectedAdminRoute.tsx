import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { Loader2 } from 'lucide-react';

interface ProtectedAdminRouteProps {
  children: React.ReactNode;
}

export default function ProtectedAdminRoute({ children }: ProtectedAdminRouteProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [isPermitted, setIsPermitted] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const checkPermission = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        
        if (!user) {
          navigate('/login');
          return;
        }

        const { data: userData, error } = await supabase
          .from('usuarios')
          .select('tipo')
          .eq('id', user.id)
          .single();

        if (error) throw error;

        if (userData.tipo !== 'admin') {
          navigate('/unauthorized');
          return;
        }

        setIsPermitted(true);
      } catch (error) {
        console.error('Erro ao verificar permissões:', error);
        navigate('/unauthorized');
      } finally {
        setIsLoading(false);
      }
    };

    checkPermission();
  }, [navigate]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return isPermitted ? <>{children}</> : null;
} 