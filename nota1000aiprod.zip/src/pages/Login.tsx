import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, ArrowRight, Mail, Lock } from "lucide-react";
import { toast } from "@/components/ui/use-toast";
import { supabase } from "@/lib/supabaseClient";

const Login = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      toast({
        title: "Login realizado",
        description: "Bem-vindo de volta ao Nota1000.AI",
      });

      navigate("/");
    } catch (error: any) {
      toast({
        title: "Erro ao fazer login",
        description: error.message || "Ocorreu um erro ao tentar fazer login. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row overflow-hidden bg-gradient-to-br from-white to-gray-50">
      <div className="hidden md:flex md:w-1/2 bg-nota-blue p-8 text-white items-center justify-center relative overflow-hidden">
        {/* Abstract background pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute -left-10 top-10 w-40 h-40 rounded-full bg-white"></div>
          <div className="absolute right-10 top-40 w-60 h-60 rounded-full bg-white"></div>
          <div className="absolute bottom-20 left-20 w-80 h-80 rounded-full bg-white"></div>
        </div>
        
        <div className="relative max-w-md space-y-8 animate-fade-in">
          <div className="space-y-3">
            <h1 className="text-4xl font-bold tracking-tight">Redações com IA nunca foi tão fácil</h1>
            <p className="text-lg opacity-90 leading-relaxed">
              Receba feedback instantâneo com análises detalhadas e sugestões personalizadas baseadas em critérios do ENEM.
            </p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl border border-white/20 shadow-xl">
            <h3 className="font-medium text-lg mb-4">Transforme sua experiência de correção</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <span className="flex items-center justify-center bg-white/20 p-1.5 rounded-md mr-3 mt-0.5">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                </span>
                <span className="opacity-90">Correção completa em menos de 30 segundos</span>
              </li>
              <li className="flex items-start">
                <span className="flex items-center justify-center bg-white/20 p-1.5 rounded-md mr-3 mt-0.5">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                </span>
                <span className="opacity-90">Feedback detalhado por competência do ENEM</span>
              </li>
              <li className="flex items-start">
                <span className="flex items-center justify-center bg-white/20 p-1.5 rounded-md mr-3 mt-0.5">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                </span>
                <span className="opacity-90">Relatórios e análises sobre o progresso do aluno</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="w-full md:w-1/2 flex items-center justify-center p-8">
        <Card className="w-full max-w-md shadow-xl border-0 bg-white/80 backdrop-blur-sm animate-scale-in">
          <CardHeader className="space-y-3 pb-8">
            <div className="flex items-center justify-center h-14 w-14 rounded-full bg-nota-blue/10 mb-3">
              <FileText className="h-7 w-7 text-nota-blue" />
            </div>
            <CardTitle className="text-2xl font-bold text-center tracking-tight">Bem-vindo de volta</CardTitle>
            <CardDescription className="text-center text-base">
              Entre com suas credenciais para acessar a plataforma
            </CardDescription>
          </CardHeader>
          
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Label htmlFor="email" className="text-base font-medium">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <Input 
                    id="email" 
                    type="email" 
                    placeholder="seu@email.com" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10 py-6 border-gray-200 focus:border-nota-blue focus:ring-nota-blue/20" 
                    required 
                  />
                </div>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password" className="text-base font-medium">Senha</Label>
                  <Link 
                    to="/forgot-password" 
                    className="text-sm font-medium text-nota-blue hover:text-nota-blue-700 transition-colors"
                  >
                    Esqueceu a senha?
                  </Link>
                </div>
                
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <Input 
                    id="password" 
                    type="password" 
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 py-6 border-gray-200 focus:border-nota-blue focus:ring-nota-blue/20" 
                    required 
                  />
                </div>
              </div>
            </CardContent>
            
            <CardFooter className="flex flex-col space-y-5 pt-2">
              <Button 
                type="submit" 
                className="w-full py-6 text-base font-medium bg-nota-blue hover:bg-nota-blue-700 transition-all duration-300 shadow-md hover:shadow-lg flex items-center justify-center gap-2 group"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>Entrando...</>
                ) : (
                  <>
                    Entrar
                    <ArrowRight className="h-4 w-4 ml-1 transition-transform group-hover:translate-x-1" />
                  </>
                )}
              </Button>
              
              <div className="text-center text-gray-600">
                Não tem uma conta?{" "}
                <Link to="/signup" className="font-medium text-nota-blue hover:text-nota-blue-700 transition-colors underline decoration-2 underline-offset-2">
                  Criar agora
                </Link>
              </div>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  );
};

export default Login;
