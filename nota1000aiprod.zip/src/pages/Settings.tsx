
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { toast } from "@/components/ui/use-toast";
import { User, Globe, Bell, Trash2, RotateCcw, Save, Lock, Palette } from "lucide-react";

const Settings = () => {
  const [name, setName] = useState('José Silva');
  const [email, setEmail] = useState('jose.silva@exemplo.com');
  const [language, setLanguage] = useState('pt-BR');
  const [theme, setTheme] = useState('light');
  const [showPlagiarismAlerts, setShowPlagiarismAlerts] = useState(true);
  const [autoExport, setAutoExport] = useState(false);
  const [emailNotifications, setEmailNotifications] = useState(true);
  
  const handleSaveChanges = () => {
    toast({
      title: "Configurações salvas",
      description: "Suas preferências foram atualizadas com sucesso.",
    });
  };
  
  const handleDeleteAccount = () => {
    // In a real app, this would handle account deletion
    console.log('Account deletion requested');
    toast({
      title: "Conta excluída",
      description: "Sua conta foi excluída permanentemente.",
      variant: "destructive"
    });
  };
  
  const handleResetHistory = () => {
    // In a real app, this would handle history reset
    console.log('History reset requested');
    toast({
      title: "Histórico resetado",
      description: "Seu histórico de redações foi apagado.",
      variant: "destructive"
    });
  };
  
  return (
    <div className="container max-w-4xl py-8 animate-fade-in">
      <h1 className="text-3xl font-bold mb-2">Configurações</h1>
      <p className="text-gray-600 mb-6">Gerencie suas preferências e configurações da plataforma</p>
      
      <Tabs defaultValue="account" className="w-full">
        <TabsList className="grid grid-cols-4 mb-8">
          <TabsTrigger value="account" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            <span className="hidden sm:inline">Conta</span>
          </TabsTrigger>
          <TabsTrigger value="preferences" className="flex items-center gap-2">
            <Palette className="h-4 w-4" />
            <span className="hidden sm:inline">Preferências</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            <span className="hidden sm:inline">Notificações</span>
          </TabsTrigger>
          <TabsTrigger value="danger" className="flex items-center gap-2">
            <Trash2 className="h-4 w-4" />
            <span className="hidden sm:inline">Zona de Perigo</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="account">
          <Card>
            <CardHeader>
              <CardTitle>Informações da Conta</CardTitle>
              <CardDescription>
                Atualize seus dados pessoais e gerencia sua conta
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">Nome completo</Label>
                <Input 
                  id="name" 
                  value={name} 
                  onChange={(e) => setName(e.target.value)} 
                  className="max-w-md"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input 
                  id="email" 
                  type="email" 
                  value={email} 
                  onChange={(e) => setEmail(e.target.value)} 
                  className="max-w-md"
                />
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <Label htmlFor="current-password">Alterar senha</Label>
                <Input 
                  id="current-password" 
                  type="password" 
                  placeholder="Senha atual" 
                  className="max-w-md mb-2"
                />
                <Input 
                  id="new-password" 
                  type="password" 
                  placeholder="Nova senha" 
                  className="max-w-md mb-2"
                />
                <Input 
                  id="confirm-password" 
                  type="password" 
                  placeholder="Confirmar nova senha" 
                  className="max-w-md"
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSaveChanges} className="bg-nota-blue hover:bg-nota-blue-700 flex items-center gap-2">
                <Save className="h-4 w-4" />
                Salvar alterações
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="preferences">
          <Card>
            <CardHeader>
              <CardTitle>Preferências da Plataforma</CardTitle>
              <CardDescription>
                Personalize sua experiência de uso do Nota1000.AI
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="language">Idioma da interface</Label>
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger className="max-w-xs">
                    <SelectValue placeholder="Selecione o idioma" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pt-BR">Português (Brasil)</SelectItem>
                    <SelectItem value="en-US">English (United States)</SelectItem>
                    <SelectItem value="es">Español</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-sm text-gray-500 mt-1">
                  Altera o idioma de toda a plataforma
                </p>
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <Label htmlFor="theme">Tema visual</Label>
                <Select value={theme} onValueChange={setTheme}>
                  <SelectTrigger className="max-w-xs">
                    <SelectValue placeholder="Selecione o tema" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Claro</SelectItem>
                    <SelectItem value="dark">Escuro</SelectItem>
                    <SelectItem value="system">Sistema</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-sm text-gray-500 mt-1">
                  Personaliza a aparência da interface
                </p>
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="plagiarism-detection" className="font-medium">
                    Detecção de plágio
                  </Label>
                  <p className="text-sm text-gray-500">
                    Verificar automaticamente por conteúdo plagiado
                  </p>
                </div>
                <Switch 
                  id="plagiarism-detection" 
                  checked={showPlagiarismAlerts} 
                  onCheckedChange={setShowPlagiarismAlerts}
                />
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="auto-export" className="font-medium">
                    Exportação automática
                  </Label>
                  <p className="text-sm text-gray-500">
                    Gerar PDF automaticamente após correção
                  </p>
                </div>
                <Switch 
                  id="auto-export" 
                  checked={autoExport} 
                  onCheckedChange={setAutoExport}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSaveChanges} className="bg-nota-blue hover:bg-nota-blue-700 flex items-center gap-2">
                <Save className="h-4 w-4" />
                Salvar preferências
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Notificações</CardTitle>
              <CardDescription>
                Escolha como deseja receber atualizações e alertas
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="email-notifications" className="font-medium">
                    Notificações por email
                  </Label>
                  <p className="text-sm text-gray-500">
                    Receba resumos semanais e correções por email
                  </p>
                </div>
                <Switch 
                  id="email-notifications" 
                  checked={emailNotifications} 
                  onCheckedChange={setEmailNotifications}
                />
              </div>
              
              <Separator />
              
              <div>
                <h3 className="font-medium mb-2">Frequência de relatórios</h3>
                <div className="grid grid-cols-3 gap-2">
                  <div className="flex items-center space-x-2 border rounded-md p-3">
                    <input type="radio" id="frequency-never" name="report-frequency" />
                    <label htmlFor="frequency-never">Nunca</label>
                  </div>
                  <div className="flex items-center space-x-2 border rounded-md p-3">
                    <input type="radio" id="frequency-weekly" name="report-frequency" checked />
                    <label htmlFor="frequency-weekly">Semanal</label>
                  </div>
                  <div className="flex items-center space-x-2 border rounded-md p-3">
                    <input type="radio" id="frequency-monthly" name="report-frequency" />
                    <label htmlFor="frequency-monthly">Mensal</label>
                  </div>
                </div>
                <p className="text-sm text-gray-500 mt-2">
                  Define a frequência dos relatórios de progresso
                </p>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSaveChanges} className="bg-nota-blue hover:bg-nota-blue-700 flex items-center gap-2">
                <Save className="h-4 w-4" />
                Salvar configurações
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="danger">
          <Card className="border-red-100">
            <CardHeader>
              <CardTitle className="text-red-600 flex items-center gap-2">
                <Trash2 className="h-5 w-5" />
                Zona de Perigo
              </CardTitle>
              <CardDescription>
                Ações irreversíveis que afetam sua conta e dados
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
              <div className="bg-red-50 border border-red-200 rounded-md p-4">
                <h3 className="font-medium text-red-800 mb-2 flex items-center gap-2">
                  <RotateCcw className="h-4 w-4" />
                  Resetar Histórico
                </h3>
                <p className="text-sm text-red-700 mb-4">
                  Esta ação irá apagar permanentemente todo o seu histórico de redações. Os dados não poderão ser recuperados.
                </p>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="outline" className="border-red-300 text-red-700 hover:bg-red-100">
                      Resetar histórico
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Tem certeza?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Esta ação irá apagar permanentemente todo o seu histórico de redações.
                        Esta ação não pode ser desfeita.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                      <AlertDialogAction 
                        onClick={handleResetHistory}
                        className="bg-red-600 hover:bg-red-700"
                      >
                        Sim, resetar histórico
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
              
              <div className="bg-red-50 border border-red-200 rounded-md p-4">
                <h3 className="font-medium text-red-800 mb-2 flex items-center gap-2">
                  <Trash2 className="h-4 w-4" />
                  Excluir Conta
                </h3>
                <p className="text-sm text-red-700 mb-4">
                  Ao excluir sua conta, você perderá acesso a todos os seus dados, redações e histórico. Esta ação é irreversível.
                </p>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive">
                      Excluir minha conta
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Tem certeza?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Esta ação não pode ser desfeita. Isso excluirá permanentemente sua conta 
                        e removerá todos os seus dados de nossos servidores.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                      <AlertDialogAction 
                        onClick={handleDeleteAccount}
                        className="bg-red-600 hover:bg-red-700"
                      >
                        Sim, excluir minha conta
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Settings;
