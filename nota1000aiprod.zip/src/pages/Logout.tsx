import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/lib/supabaseClient";
import { toast } from "@/components/ui/use-toast";

const Logout = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const handleLogout = async () => {
      try {
        const { error } = await supabase.auth.signOut();
        
        if (error) throw error;

        // Limpar dados locais
        localStorage.removeItem("user");
        sessionStorage.clear();

        toast({
          title: "Logout realizado",
          description: "Você foi desconectado com sucesso.",
        });

        // Redirecionar para a landing page
        navigate("/");
      } catch (error: any) {
        toast({
          title: "Erro ao fazer logout",
          description: error.message || "Ocorreu um erro ao tentar fazer logout. Tente novamente.",
          variant: "destructive",
        });
        navigate("/");
      }
    };

    handleLogout();
  }, [navigate]);

  return null;
};

export default Logout;
