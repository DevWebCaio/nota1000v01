import { createClient } from '@supabase/supabase-js';

const supabaseUrl = "https://wmisguzdmxjadagdofmv.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndtaXNndXpkbXhqYWRhZ2RvZm12Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDY5MjgwMDcsImV4cCI6MjA2MjUwNDAwN30.wvPYzcdsfrms2WIiRSPZA4oTbiXM3SxvC4B4NCxfxaQ";

export const supabase = createClient(supabaseUrl, supabaseAnonKey); 