
import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, FileText, Info } from "lucide-react";
import { Link } from 'react-router-dom';

const Plans = () => {
  return (
    <div className="container max-w-6xl py-12 animate-fade-in">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-3">Escolha o plano ideal para você</h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Seja para professores individuais ou instituições de ensino, temos um plano que se adapta às suas necessidades.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Plano Iniciante */}
        <Card className="border-gray-200 shadow-lg hover:shadow-xl transition-shadow duration-300 relative overflow-hidden">
          <div className="absolute top-0 right-0 left-0 h-1 bg-gray-300"></div>
          <CardHeader className="pb-8">
            <div className="mb-2">
              <Badge variant="outline" className="bg-gray-100">
                Iniciante
              </Badge>
            </div>
            <CardTitle className="text-2xl font-bold">Plano Básico</CardTitle>
            <CardDescription className="text-gray-500">
              Para professores que estão começando
            </CardDescription>
            <div className="mt-4">
              <span className="text-4xl font-bold">R$ 20</span>
              <span className="text-gray-500 ml-2">/mês</span>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <ul className="space-y-3">
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                <span>10 redações por mês</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                <span>Correção em até 30 segundos</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                <span>Feedback detalhado por competência</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                <span>Histórico de redações</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter className="flex flex-col space-y-3 pt-2">
            <Button className="w-full py-6 bg-gray-800 hover:bg-gray-900 transition-colors">
              Assinar Agora
            </Button>
            <a href="#comparativo" className="text-sm text-center text-gray-500 hover:text-gray-700">
              Ver detalhes do plano
            </a>
          </CardFooter>
        </Card>

        {/* Plano Premium */}
        <Card className="border-nota-blue shadow-xl hover:shadow-2xl transition-shadow duration-300 relative overflow-hidden scale-105 z-10">
          <div className="absolute -top-4 left-0 right-0 text-center">
            <span className="bg-nota-green text-white text-xs font-bold px-4 py-1 rounded-full">
              RECOMENDADO
            </span>
          </div>
          <div className="absolute top-0 right-0 left-0 h-1 bg-nota-blue"></div>
          <CardHeader className="pb-8 pt-6">
            <div className="mb-2">
              <Badge className="bg-nota-blue text-white">
                Premium
              </Badge>
            </div>
            <CardTitle className="text-2xl font-bold">Plano Profissional</CardTitle>
            <CardDescription className="text-gray-500">
              Para profissionais que buscam mais recursos
            </CardDescription>
            <div className="mt-4">
              <span className="text-4xl font-bold">R$ 90</span>
              <span className="text-gray-500 ml-2">/mês</span>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <ul className="space-y-3">
              <li className="flex items-start">
                <Check className="h-5 w-5 text-nota-blue mr-2 mt-0.5 flex-shrink-0" />
                <span>100 redações por mês</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-nota-blue mr-2 mt-0.5 flex-shrink-0" />
                <span>Correção em até 30 segundos</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-nota-blue mr-2 mt-0.5 flex-shrink-0" />
                <span>Feedback detalhado avançado</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-nota-blue mr-2 mt-0.5 flex-shrink-0" />
                <span>Exportação em PDF</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-nota-blue mr-2 mt-0.5 flex-shrink-0" />
                <span>Detecção de plágio</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-nota-blue mr-2 mt-0.5 flex-shrink-0" />
                <span>Gráficos de evolução</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter className="flex flex-col space-y-3 pt-2">
            <Button className="w-full py-6 bg-nota-blue hover:bg-nota-blue-700 transition-colors">
              Assinar Agora
            </Button>
            <a href="#comparativo" className="text-sm text-center text-gray-500 hover:text-nota-blue">
              Ver detalhes do plano
            </a>
          </CardFooter>
        </Card>

        {/* Plano Mestre */}
        <Card className="border-gray-200 shadow-lg hover:shadow-xl transition-shadow duration-300 relative overflow-hidden">
          <div className="absolute top-0 right-0 left-0 h-1 bg-nota-green"></div>
          <CardHeader className="pb-8">
            <div className="mb-2">
              <Badge variant="outline" className="bg-nota-green/10 text-nota-green border-nota-green">
                Mestre da Redação
              </Badge>
            </div>
            <CardTitle className="text-2xl font-bold">Plano Institucional</CardTitle>
            <CardDescription className="text-gray-500">
              Para escolas e cursinos preparatórios
            </CardDescription>
            <div className="mt-4">
              <span className="text-4xl font-bold">R$ 150</span>
              <span className="text-gray-500 ml-2">/mês</span>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <ul className="space-y-3">
              <li className="flex items-start">
                <Check className="h-5 w-5 text-nota-green mr-2 mt-0.5 flex-shrink-0" />
                <span>Redações ilimitadas</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-nota-green mr-2 mt-0.5 flex-shrink-0" />
                <span>Correção em até 30 segundos</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-nota-green mr-2 mt-0.5 flex-shrink-0" />
                <span>Feedback detalhado avançado</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-nota-green mr-2 mt-0.5 flex-shrink-0" />
                <span>Exportação em PDF e Word</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-nota-green mr-2 mt-0.5 flex-shrink-0" />
                <span>Detecção de plágio premium</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-nota-green mr-2 mt-0.5 flex-shrink-0" />
                <span>Relatórios detalhados por turma</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-nota-green mr-2 mt-0.5 flex-shrink-0" />
                <span>Suporte prioritário 24/7</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter className="flex flex-col space-y-3 pt-2">
            <Button className="w-full py-6 bg-nota-green hover:bg-nota-green-700 transition-colors">
              Assinar Agora
            </Button>
            <a href="#comparativo" className="text-sm text-center text-gray-500 hover:text-nota-green">
              Ver detalhes do plano
            </a>
          </CardFooter>
        </Card>
      </div>

      {/* Comparativo de recursos */}
      <div id="comparativo" className="mt-24 pt-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-3">Comparativo de recursos</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Veja em detalhes as diferenças entre cada plano e escolha o que melhor se adapta às suas necessidades.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b-2 border-gray-200">
                <th className="p-4 text-left min-w-[200px]">Recursos</th>
                <th className="p-4 text-center">Básico</th>
                <th className="p-4 text-center bg-blue-50">Profissional</th>
                <th className="p-4 text-center">Institucional</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-gray-200">
                <td className="p-4 text-left font-medium">Redações por mês</td>
                <td className="p-4 text-center">10</td>
                <td className="p-4 text-center bg-blue-50">100</td>
                <td className="p-4 text-center">Ilimitado</td>
              </tr>
              <tr className="border-b border-gray-200">
                <td className="p-4 text-left font-medium">Tempo de correção</td>
                <td className="p-4 text-center">30 segundos</td>
                <td className="p-4 text-center bg-blue-50">30 segundos</td>
                <td className="p-4 text-center">30 segundos</td>
              </tr>
              <tr className="border-b border-gray-200">
                <td className="p-4 text-left font-medium">Exportação em PDF</td>
                <td className="p-4 text-center">
                  <Info className="h-5 w-5 text-red-500 mx-auto" />
                </td>
                <td className="p-4 text-center bg-blue-50">
                  <Check className="h-5 w-5 text-nota-blue mx-auto" />
                </td>
                <td className="p-4 text-center">
                  <Check className="h-5 w-5 text-green-500 mx-auto" />
                </td>
              </tr>
              <tr className="border-b border-gray-200">
                <td className="p-4 text-left font-medium">Exportação em Word</td>
                <td className="p-4 text-center">
                  <Info className="h-5 w-5 text-red-500 mx-auto" />
                </td>
                <td className="p-4 text-center bg-blue-50">
                  <Info className="h-5 w-5 text-red-500 mx-auto" />
                </td>
                <td className="p-4 text-center">
                  <Check className="h-5 w-5 text-green-500 mx-auto" />
                </td>
              </tr>
              <tr className="border-b border-gray-200">
                <td className="p-4 text-left font-medium">Detecção de plágio</td>
                <td className="p-4 text-center">
                  <Info className="h-5 w-5 text-red-500 mx-auto" />
                </td>
                <td className="p-4 text-center bg-blue-50">
                  <Check className="h-5 w-5 text-nota-blue mx-auto" />
                </td>
                <td className="p-4 text-center">
                  <Check className="h-5 w-5 text-green-500 mx-auto" />
                </td>
              </tr>
              <tr className="border-b border-gray-200">
                <td className="p-4 text-left font-medium">Gráficos de evolução</td>
                <td className="p-4 text-center">
                  <Info className="h-5 w-5 text-red-500 mx-auto" />
                </td>
                <td className="p-4 text-center bg-blue-50">
                  <Check className="h-5 w-5 text-nota-blue mx-auto" />
                </td>
                <td className="p-4 text-center">
                  <Check className="h-5 w-5 text-green-500 mx-auto" />
                </td>
              </tr>
              <tr className="border-b border-gray-200">
                <td className="p-4 text-left font-medium">Relatórios por turma</td>
                <td className="p-4 text-center">
                  <Info className="h-5 w-5 text-red-500 mx-auto" />
                </td>
                <td className="p-4 text-center bg-blue-50">
                  <Info className="h-5 w-5 text-red-500 mx-auto" />
                </td>
                <td className="p-4 text-center">
                  <Check className="h-5 w-5 text-green-500 mx-auto" />
                </td>
              </tr>
              <tr className="border-b border-gray-200">
                <td className="p-4 text-left font-medium">Suporte prioritário</td>
                <td className="p-4 text-center">
                  <Info className="h-5 w-5 text-red-500 mx-auto" />
                </td>
                <td className="p-4 text-center bg-blue-50">
                  <Info className="h-5 w-5 text-red-500 mx-auto" />
                </td>
                <td className="p-4 text-center">
                  <Check className="h-5 w-5 text-green-500 mx-auto" />
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* FAQ ou Call to Action */}
      <div className="mt-24 bg-gray-50 p-10 rounded-2xl text-center">
        <FileText className="h-12 w-12 text-nota-blue mx-auto mb-4" />
        <h2 className="text-2xl font-bold mb-2">Ainda tem dúvidas?</h2>
        <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
          Entre em contato com nosso time de suporte para obter mais informações sobre nossos planos ou agende uma demonstração personalizada.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Button className="bg-nota-blue hover:bg-nota-blue-700 transition-colors px-6 py-3">
            Contatar Suporte
          </Button>
          <Button variant="outline" className="hover:bg-gray-100 transition-colors px-6 py-3">
            Agendar Demonstração
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Plans;
