import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, ArrowRight, Mail, Lock, Loader2, ArrowLeft } from "lucide-react";
import { toast } from "@/components/ui/use-toast";
import { supabase } from "@/lib/supabaseClient";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";

const Signup = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [tipo, setTipo] = useState<"aluno" | "professor">("aluno");
  const [nome, setNome] = useState("");
  const [instituicao, setInstituicao] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    // Validações
    if (password !== confirmPassword) {
      setError("As senhas não coincidem");
      setIsLoading(false);
      return;
    }

    if (password.length < 6) {
      setError("A senha deve ter pelo menos 6 caracteres");
      setIsLoading(false);
      return;
    }

    try {
      // 1. Criar usuário no Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
      });

      if (authError) throw authError;

      if (!authData.user) {
        throw new Error("Erro ao criar usuário");
      }

      // 2. Inserir dados adicionais na tabela usuarios
      const { error: profileError } = await supabase
        .from("usuarios")
        .insert([
          {
            id: authData.user.id,
            email: email,
            nome: nome,
            tipo: tipo,
            instituicao: instituicao,
            created_at: new Date().toISOString(),
          },
        ]);

      if (profileError) throw profileError;

      toast({
        title: "Conta criada com sucesso!",
        description: "Você já pode fazer login com suas credenciais.",
      });

      // 3. Redirecionar para login
      navigate("/login");
    } catch (error: any) {
      setError(error.message);
      toast({
        title: "Erro ao criar conta",
        description: error.message || "Não foi possível criar sua conta. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row overflow-hidden bg-gradient-to-br from-white to-gray-50">
      <div className="hidden md:flex md:w-1/2 bg-nota-blue p-8 text-white items-center justify-center relative overflow-hidden">
        {/* Abstract background pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute -left-10 top-10 w-40 h-40 rounded-full bg-white"></div>
          <div className="absolute right-10 top-40 w-60 h-60 rounded-full bg-white"></div>
          <div className="absolute bottom-20 left-20 w-80 h-80 rounded-full bg-white"></div>
        </div>
        
        <div className="relative max-w-md space-y-8 animate-fade-in">
          <div className="space-y-3">
            <h1 className="text-4xl font-bold tracking-tight">Junte-se à plataforma líder de redações com IA</h1>
            <p className="text-lg opacity-90 leading-relaxed">
              Corrija redações com IA e acompanhe seu progresso com análises detalhadas baseadas nos critérios do ENEM.
            </p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl border border-white/20 shadow-xl">
            <h3 className="font-medium text-lg mb-4">Nota1000.AI oferece:</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <span className="flex items-center justify-center bg-white/20 p-1.5 rounded-md mr-3 mt-0.5">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                </span>
                <span className="opacity-90">Correção automática baseada nos critérios ENEM</span>
              </li>
              <li className="flex items-start">
                <span className="flex items-center justify-center bg-white/20 p-1.5 rounded-md mr-3 mt-0.5">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                </span>
                <span className="opacity-90">Dicas personalizadas para melhorar a escrita</span>
              </li>
              <li className="flex items-start">
                <span className="flex items-center justify-center bg-white/20 p-1.5 rounded-md mr-3 mt-0.5">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                </span>
                <span className="opacity-90">Acompanhamento de progresso com gráficos detalhados</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="w-full md:w-1/2 flex items-center justify-center p-8">
        <Card className="w-full max-w-md shadow-xl border-0 bg-white/80 backdrop-blur-sm animate-scale-in">
          <CardHeader className="space-y-3 pb-8">
            <div className="flex items-center justify-center h-14 w-14 rounded-full bg-nota-blue/10 mb-3">
              <FileText className="h-7 w-7 text-nota-blue" />
            </div>
            <CardTitle className="text-2xl font-bold text-center tracking-tight">Criar uma conta</CardTitle>
            <CardDescription className="text-center text-base">
              Preencha os dados abaixo para começar
            </CardDescription>
          </CardHeader>
          
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-5">
              <div className="space-y-3">
                <Label htmlFor="nome">Nome Completo</Label>
                <Input
                  id="nome"
                  type="text"
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  placeholder="Digite seu nome completo"
                  required
                />
              </div>

              <div className="space-y-3">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Digite seu email"
                  required
                />
              </div>

              <div className="space-y-3">
                <Label htmlFor="tipo">Tipo de Usuário</Label>
                <Select
                  value={tipo}
                  onValueChange={(value: "aluno" | "professor") => setTipo(value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o tipo de usuário" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="aluno">Aluno</SelectItem>
                    <SelectItem value="professor">Professor</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-3">
                <Label htmlFor="instituicao">Instituição</Label>
                <Input
                  id="instituicao"
                  type="text"
                  value={instituicao}
                  onChange={(e) => setInstituicao(e.target.value)}
                  placeholder="Digite sua instituição de ensino"
                  required
                />
              </div>

              <div className="space-y-3">
                <Label htmlFor="password">Senha</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Digite sua senha"
                  required
                />
              </div>
              
              <div className="space-y-3">
                <Label htmlFor="confirmPassword">Confirmar Senha</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirme sua senha"
                  required
                />
              </div>

              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
            </CardContent>
            
            <CardFooter className="flex flex-col space-y-5 pt-2">
              <Button 
                type="submit" 
                className="w-full py-6 text-base font-medium bg-nota-blue hover:bg-nota-blue-700 transition-all duration-300 shadow-md hover:shadow-lg flex items-center justify-center gap-2 group"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Criando conta...
                  </>
                ) : (
                  <>
                    Criar conta
                    <ArrowRight className="h-4 w-4 ml-1 transition-transform group-hover:translate-x-1" />
                  </>
                )}
              </Button>
              
              <div className="text-center text-gray-600">
                Já tem uma conta?{" "}
                <Link to="/login" className="font-medium text-nota-blue hover:text-nota-blue-700 transition-colors underline decoration-2 underline-offset-2">
                  Entrar
                </Link>
              </div>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  );
};

export default Signup;
