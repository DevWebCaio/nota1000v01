import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/lib/supabase";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Users, FileText, UserPlus, UserMinus, Edit2, Ban } from "lucide-react";
import { toast } from "@/components/ui/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface DashboardStats {
  totalAlunos: number;
  totalProfessores: number;
  totalRedacoes: number;
  correcoesPendentes: number;
}

interface Usuario {
  id: string;
  email: string;
  nome: string;
  tipo: string;
  instituicao: string;
  created_at: string;
}

interface UsoDiario {
  data: string;
  redacoes: number;
}

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [usuarios, setUsuarios] = useState<Usuario[]>([]);
  const [usoDiario, setUsoDiario] = useState<UsoDiario[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedUser, setSelectedUser] = useState<Usuario | null>(null);
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setIsLoading(true);
      
      // Buscar estatísticas
      const { data: usuariosData, error: usuariosError } = await supabase
        .from('usuarios')
        .select('*');

      if (usuariosError) throw usuariosError;

      const { data: redacoesData, error: redacoesError } = await supabase
        .from('redacoes')
        .select('*');

      if (redacoesError) throw redacoesError;

      const { data: correcoesData, error: correcoesError } = await supabase
        .from('correcoes')
        .select('*')
        .is('nota_total', null);

      if (correcoesError) throw correcoesError;

      // Calcular estatísticas
      const stats: DashboardStats = {
        totalAlunos: usuariosData.filter(u => u.tipo === 'aluno').length,
        totalProfessores: usuariosData.filter(u => u.tipo === 'professor').length,
        totalRedacoes: redacoesData.length,
        correcoesPendentes: correcoesData.length
      };

      setStats(stats);
      setUsuarios(usuariosData);

      // Calcular uso diário
      const usoPorDia = redacoesData.reduce((acc: { [key: string]: number }, redacao) => {
        const data = new Date(redacao.created_at).toISOString().split('T')[0];
        acc[data] = (acc[data] || 0) + 1;
        return acc;
      }, {});

      const usoDiarioArray = Object.entries(usoPorDia).map(([data, redacoes]) => ({
        data,
        redacoes
      })).sort((a, b) => new Date(a.data).getTime() - new Date(b.data).getTime());

      setUsoDiario(usoDiarioArray);

    } catch (error: any) {
      setError(error.message);
      toast({
        title: "Erro ao carregar dados",
        description: "Não foi possível carregar os dados do dashboard.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleUserAction = async (userId: string, action: 'ban' | 'promote' | 'edit') => {
    try {
      if (action === 'ban') {
        const { error } = await supabase
          .from('usuarios')
          .update({ tipo: 'banido' })
          .eq('id', userId);

        if (error) throw error;
        toast({
          title: "Usuário banido",
          description: "O usuário foi banido com sucesso.",
        });
      } else if (action === 'promote') {
        const { error } = await supabase
          .from('usuarios')
          .update({ tipo: 'professor' })
          .eq('id', userId);

        if (error) throw error;
        toast({
          title: "Usuário promovido",
          description: "O usuário foi promovido a professor com sucesso.",
        });
      }

      fetchDashboardData();
    } catch (error: any) {
      toast({
        title: "Erro ao executar ação",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleEditUser = async (userId: string, updates: Partial<Usuario>) => {
    try {
      const { error } = await supabase
        .from('usuarios')
        .update(updates)
        .eq('id', userId);

      if (error) throw error;

      toast({
        title: "Usuário atualizado",
        description: "Os dados do usuário foram atualizados com sucesso.",
      });

      setIsEditing(false);
      fetchDashboardData();
    } catch (error: any) {
      toast({
        title: "Erro ao atualizar usuário",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-nota-blue" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <h1 className="text-2xl font-bold">Painel Administrativo</h1>

        {error ? (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        ) : (
          <>
            {/* Cards de Estatísticas */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total de Alunos</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.totalAlunos}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total de Professores</CardTitle>
                  <UserPlus className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.totalProfessores}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total de Redações</CardTitle>
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.totalRedacoes}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Correções Pendentes</CardTitle>
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.correcoesPendentes}</div>
                </CardContent>
              </Card>
            </div>

            {/* Gráfico de Uso */}
            <Card>
              <CardHeader>
                <CardTitle>Uso por Dia</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={usoDiario}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="data" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="redacoes" stroke="#2563eb" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Lista de Usuários */}
            <Card>
              <CardHeader>
                <CardTitle>Usuários</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Instituição</TableHead>
                      <TableHead>Data de Registro</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {usuarios.map((usuario) => (
                      <TableRow key={usuario.id}>
                        <TableCell>{usuario.nome}</TableCell>
                        <TableCell>{usuario.email}</TableCell>
                        <TableCell>{usuario.tipo}</TableCell>
                        <TableCell>{usuario.instituicao}</TableCell>
                        <TableCell>
                          {new Date(usuario.created_at).toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => {
                                    setSelectedUser(usuario);
                                    setIsEditing(true);
                                  }}
                                >
                                  <Edit2 className="h-4 w-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Editar Usuário</DialogTitle>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <div>
                                    <Label htmlFor="nome">Nome</Label>
                                    <Input
                                      id="nome"
                                      defaultValue={usuario.nome}
                                      onChange={(e) =>
                                        setSelectedUser(prev => prev ? { ...prev, nome: e.target.value } : null)
                                      }
                                    />
                                  </div>
                                  <div>
                                    <Label htmlFor="email">Email</Label>
                                    <Input
                                      id="email"
                                      defaultValue={usuario.email}
                                      onChange={(e) =>
                                        setSelectedUser(prev => prev ? { ...prev, email: e.target.value } : null)
                                      }
                                    />
                                  </div>
                                  <div>
                                    <Label htmlFor="tipo">Tipo</Label>
                                    <Select
                                      defaultValue={usuario.tipo}
                                      onValueChange={(value) =>
                                        setSelectedUser(prev => prev ? { ...prev, tipo: value } : null)
                                      }
                                    >
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="aluno">Aluno</SelectItem>
                                        <SelectItem value="professor">Professor</SelectItem>
                                        <SelectItem value="admin">Admin</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </div>
                                  <div>
                                    <Label htmlFor="instituicao">Instituição</Label>
                                    <Input
                                      id="instituicao"
                                      defaultValue={usuario.instituicao}
                                      onChange={(e) =>
                                        setSelectedUser(prev => prev ? { ...prev, instituicao: e.target.value } : null)
                                      }
                                    />
                                  </div>
                                  <Button
                                    onClick={() => selectedUser && handleEditUser(usuario.id, selectedUser)}
                                  >
                                    Salvar Alterações
                                  </Button>
                                </div>
                              </DialogContent>
                            </Dialog>

                            {usuario.tipo !== 'professor' && (
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleUserAction(usuario.id, 'promote')}
                              >
                                <UserPlus className="h-4 w-4" />
                              </Button>
                            )}

                            {usuario.tipo !== 'banido' && (
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleUserAction(usuario.id, 'ban')}
                              >
                                <Ban className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard; 