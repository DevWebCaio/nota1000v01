
import React from 'react';
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Outlet, useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';

const AppLayout = () => {
  const location = useLocation();
  // Updated to include the landing page and plans page as pages without nav
  const isSpecialPage = location.pathname === '/login' || 
                       location.pathname === '/signup' || 
                       location.pathname === '/forgot-password' ||
                       location.pathname === '/landing';
  
  return (
    <>
      <Toaster />
      <Sonner />
      
      {!isSpecialPage && <Sidebar />}
      
      <main className={`min-h-screen ${isSpecialPage ? '' : 'md:pl-64 pt-4 px-4 sm:px-6 lg:px-8'}`}>
        <Outlet />
      </main>
    </>
  );
};

export default AppLayout;
