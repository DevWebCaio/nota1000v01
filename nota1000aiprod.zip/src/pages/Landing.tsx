
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { FileText, CheckCircle, ArrowRight, Clock, Award, BarChart, Shield, Mail, ChevronDown, ChevronUp } from "lucide-react";

const Landing = () => {
  const [email, setEmail] = useState("");
  const [isIntersecting, setIsIntersecting] = useState<Record<string, boolean>>({});
  
  // Observer for revealing animations as user scrolls
  useEffect(() => {
    const observerCallback = (entries: IntersectionObserverEntry[]) => {
      entries.forEach((entry) => {
        if (entry.target.id) {
          setIsIntersecting(prev => ({
            ...prev,
            [entry.target.id]: entry.isIntersecting
          }));
        }
      });
    };
    
    const observer = new IntersectionObserver(observerCallback, {
      root: null,
      rootMargin: '0px',
      threshold: 0.1
    });
    
    document.querySelectorAll('[data-animate]').forEach(element => {
      observer.observe(element);
    });
    
    return () => observer.disconnect();
  }, []);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Lead captured:", email);
    alert("Obrigado por se inscrever! Entraremos em contato em breve.");
    setEmail("");
  };
  
  // FAQs data
  const faqs = [
    {
      question: "Como funciona o processo de correção com IA?",
      answer: "Nossa plataforma utiliza IA avançada para analisar a estrutura, argumentação, coerência e outros aspectos críticos da redação. O sistema avalia o texto com base nos critérios do ENEM, fornecendo uma nota detalhada por competência e comentários específicos em cada trecho."
    },
    {
      question: "Quanto tempo leva para corrigir uma redação?",
      answer: "A correção é praticamente instantânea, levando em média 30 segundos para processar e avaliar uma redação completa - muito mais rápido que os 15-20 minutos necessários para uma correção manual."
    },
    {
      question: "O sistema consegue identificar plágio?",
      answer: "Sim, nossa plataforma possui uma ferramenta integrada de detecção de plágio que compara o texto enviado com um vasto banco de dados e conteúdos online, destacando trechos com possível similaridade."
    },
    {
      question: "Posso exportar as correções para compartilhar com os alunos?",
      answer: "Absolutamente! Todas as correções podem ser exportadas em formato PDF com layout profissional, incluindo a redação original, comentários, notas por competência e sugestões de melhoria."
    },
    {
      question: "Como a IA avalia competências subjetivas como argumentação?",
      answer: "Nossa IA foi treinada com milhares de redações avaliadas por professores experientes e utiliza critérios objetivos dentro de cada competência para garantir uma avaliação justa e consistente mesmo em aspectos mais subjetivos."
    }
  ];
  
  const testimonials = [
    {
      text: "Economizo pelo menos 5 horas por semana com correções de redações. O feedback é tão detalhado quanto o meu, com a vantagem de ser instantâneo.",
      name: "Profª. Amanda Silva",
      role: "Professora de Redação, Colégio Estadual"
    },
    {
      text: "Meus alunos estão recebendo feedback mais rápido e consistente. A análise por competências está ajudando a direcionar melhor as aulas de reforço.",
      name: "Prof. Carlos Eduardo",
      role: "Coordenador de Linguagens, Curso Preparatório"
    },
    {
      text: "A plataforma revolucionou nossa dinâmica de correções. Nossos professores agora focam mais tempo em explicações personalizadas e menos em correções repetitivas.",
      name: "Dra. Juliana Mendes",
      role: "Diretora Pedagógica, Rede de Escolas"
    }
  ];
  
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-nota-blue to-nota-blue-700 text-white min-h-screen flex items-center">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -right-10 top-20 w-80 h-80 rounded-full bg-white/5"></div>
          <div className="absolute left-20 bottom-40 w-60 h-60 rounded-full bg-white/10"></div>
          <div className="absolute right-1/3 bottom-10 w-40 h-40 rounded-full bg-white/5"></div>
        </div>
        
        <div className="container mx-auto px-6 py-24 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24 items-center">
            <div className="space-y-8 max-w-2xl">
              <div className="inline-block bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-medium">
                ✨ Powered by Inteligência Artificial Avançada
              </div>
              
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight tracking-tight">
                Corrija redações com IA <span className="text-nota-green">em segundos</span>, não em horas
              </h1>
              
              <p className="text-xl text-white/80 leading-relaxed">
                Plataforma completa de correção automatizada para professores, escolas e cursinhos. Nota por competência, feedbacks detalhados e relatórios prontos para enviar aos alunos.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button 
                  asChild 
                  className="bg-white text-nota-blue hover:bg-white/90 text-lg px-8 py-6 rounded-xl font-medium shadow-lg transition-all"
                >
                  <Link to="/signup" className="flex items-center">
                    Testar Grátis
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                
                <Button 
                  variant="outline" 
                  asChild 
                  className="bg-transparent border-white text-white hover:bg-white/10 text-lg px-8 py-6 rounded-xl font-medium transition-all"
                >
                  <a href="#como-funciona">Ver Demonstração</a>
                </Button>
              </div>
              
              {/* Improved stats section with better spacing and responsive design */}
              <div className="grid grid-cols-3 gap-6 pt-8 bg-white/5 p-6 rounded-xl backdrop-blur-sm">
                <div className="flex flex-col items-center text-center p-3">
                  <p className="text-2xl sm:text-4xl font-bold mb-2">30s</p>
                  <p className="text-sm sm:text-base text-white">Tempo médio de correção</p>
                </div>
                <div className="flex flex-col items-center text-center border-x border-white/10 p-3">
                  <p className="text-2xl sm:text-4xl font-bold mb-2">98%</p>
                  <p className="text-sm sm:text-base text-white">Precisão nas avaliações</p>
                </div>
                <div className="flex flex-col items-center text-center p-3">
                  <p className="text-2xl sm:text-4xl font-bold mb-2">5.000+</p>
                  <p className="text-sm sm:text-base text-white">Redações corrigidas</p>
                </div>
              </div>
            </div>
            
            <div className="relative hidden lg:block">
              <div className="relative bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20 shadow-2xl">
                <img 
                  src="https://lovable.dev/opengraph-image-p98pqg.png" 
                  alt="Plataforma Nota1000.AI" 
                  className="rounded-lg shadow-lg w-full"
                />
                <div className="absolute -right-4 -bottom-4 bg-nota-green text-white px-4 py-2 rounded-lg font-medium shadow-lg">
                  Nota: 920/1000
                </div>
              </div>
              
              <div className="absolute -bottom-10 -left-10 bg-white rounded-xl p-4 shadow-xl flex items-center space-x-4 transform rotate-6">
                <div className="bg-nota-green/20 rounded-full p-3">
                  <CheckCircle className="h-6 w-6 text-nota-green" />
                </div>
                <div>
                  <p className="font-medium text-nota-blue">Correção finalizada</p>
                  <p className="text-sm text-gray-500">Há 30 segundos</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Modified wave SVG - reduced height and adjusted position */}
        <div className="absolute bottom-0 left-0 right-0 h-16">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 100" preserveAspectRatio="none" className="w-full h-full">
            <path fill="#ffffff" fillOpacity="1" d="M0,32L48,42.7C96,53,192,75,288,74.7C384,75,480,53,576,53.3C672,53,768,75,864,80C960,85,1056,75,1152,53.3C1248,32,1344,32,1392,32L1440,32L1440,100L1392,100C1344,100,1248,100,1152,100C1056,100,960,100,864,100C768,100,672,100,576,100C480,100,384,100,288,100C192,100,96,100,48,100L0,100Z"></path>
          </svg>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-24 px-6" id="beneficios">
        <div className="container mx-auto max-w-6xl">
          <div 
            id="features-heading"
            data-animate="true"
            className="text-center max-w-3xl mx-auto mb-16 transition-all duration-700 transform"
            style={{
              opacity: isIntersecting['features-heading'] ? '1' : '0', 
              transform: isIntersecting['features-heading'] ? 'translateY(0)' : 'translateY(10px)'
            }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              Corrija redações <span className="text-nota-blue">10x mais rápido</span> com nossa plataforma
            </h2>
            <p className="text-xl text-gray-600 leading-relaxed">
              Simplificamos o processo de correção para que você possa focar no que realmente importa: o desenvolvimento dos seus alunos.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                id: "feature-1",
                icon: <Clock className="h-10 w-10 text-nota-blue" />,
                title: "Correção em segundos",
                description: "Processamento 60x mais rápido que a correção manual, sem comprometer a qualidade do feedback."
              },
              {
                id: "feature-2",
                icon: <Award className="h-10 w-10 text-nota-blue" />,
                title: "Critérios do ENEM",
                description: "Avaliação por competências específicas, exatamente como no Exame Nacional do Ensino Médio."
              },
              {
                id: "feature-3",
                icon: <BarChart className="h-10 w-10 text-nota-blue" />,
                title: "Análises detalhadas",
                description: "Gráficos de progresso e relatórios comparativos para acompanhar a evolução do aluno."
              },
              {
                id: "feature-4",
                icon: <Shield className="h-10 w-10 text-nota-blue" />,
                title: "Detecção de plágio",
                description: "Verificação automática contra milhões de fontes para garantir a originalidade das redações."
              }
            ].map((feature, index) => (
              <div 
                key={feature.id}
                id={feature.id}
                data-animate="true"
                className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 transition-all duration-700 transform"
                style={{
                  opacity: isIntersecting[feature.id] ? '1' : '0', 
                  transform: isIntersecting[feature.id] ? 'translateY(0)' : 'translateY(10px)',
                  transitionDelay: `${index * 100}ms`
                }}
              >
                <div className="bg-nota-blue/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* How It Works Section */}
      <section className="py-24 px-6 bg-gray-50" id="como-funciona">
        <div className="container mx-auto max-w-6xl">
          <div 
            id="how-it-works-heading"
            data-animate="true"
            className="text-center max-w-3xl mx-auto mb-16 transition-all duration-700 transform"
            style={{
              opacity: isIntersecting['how-it-works-heading'] ? '1' : '0', 
              transform: isIntersecting['how-it-works-heading'] ? 'translateY(0)' : 'translateY(10px)'
            }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              Como funciona o <span className="text-nota-blue">Nota1000.AI</span>
            </h2>
            <p className="text-xl text-gray-600 leading-relaxed">
              Nosso processo simples de 4 etapas torna a correção de redações mais eficiente e precisa.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div 
              id="demo-animation"
              data-animate="true"
              className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100 transition-all duration-700 transform"
              style={{
                opacity: isIntersecting['demo-animation'] ? '1' : '0', 
                transform: isIntersecting['demo-animation'] ? 'translateX(0)' : 'translateX(-10px)'
              }}
            >
              <div className="bg-gray-100 px-4 py-3 flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
                <div className="text-xs text-gray-500 ml-2">nota1000.ai</div>
              </div>
              <img 
                src="https://lovable.dev/opengraph-image-p98pqg.png" 
                alt="Demonstração do Nota1000.AI" 
                className="w-full"
              />
            </div>
            
            <div className="space-y-12">
              {[
                {
                  id: "step-1",
                  number: "01",
                  title: "Envie sua redação",
                  description: "Faça upload de um arquivo ou digite diretamente na plataforma. Aceitamos diversos formatos como PDF, DOC ou mesmo imagens."
                },
                {
                  id: "step-2",
                  number: "02",
                  title: "A IA analisa o texto",
                  description: "Nosso modelo de IA avançado processa o conteúdo, avaliando estrutura, coerência, argumentação e outros aspectos fundamentais."
                },
                {
                  id: "step-3",
                  number: "03",
                  title: "Receba a correção detalhada",
                  description: "Em segundos, obtenha uma análise completa com nota por competência e comentários específicos sobre cada trecho do texto."
                },
                {
                  id: "step-4",
                  number: "04",
                  title: "Exporte e compartilhe",
                  description: "Gere um PDF profissional com todos os comentários e notas para compartilhar com seus alunos ou guardar em seu histórico."
                }
              ].map((step, index) => (
                <div 
                  key={step.id}
                  id={step.id}
                  data-animate="true"
                  className="flex gap-6 transition-all duration-700 transform"
                  style={{
                    opacity: isIntersecting[step.id] ? '1' : '0', 
                    transform: isIntersecting[step.id] ? 'translateX(0)' : 'translateX(10px)',
                    transitionDelay: `${index * 100}ms`
                  }}
                >
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-full bg-nota-blue text-white flex items-center justify-center text-xl font-bold">
                      {step.number}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{step.title}</h3>
                    <p className="text-gray-600">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
      
      {/* Comparison Section */}
      <section className="py-24 px-6">
        <div className="container mx-auto max-w-5xl">
          <div 
            id="comparison-heading"
            data-animate="true"
            className="text-center max-w-3xl mx-auto mb-16 transition-all duration-700 transform"
            style={{
              opacity: isIntersecting['comparison-heading'] ? '1' : '0', 
              transform: isIntersecting['comparison-heading'] ? 'translateY(0)' : 'translateY(10px)'
            }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              Antes vs. Depois do <span className="text-nota-blue">Nota1000.AI</span>
            </h2>
            <p className="text-xl text-gray-600 leading-relaxed">
              Veja como nossa plataforma transforma o processo de correção de redações.
            </p>
          </div>
          
          <div 
            id="comparison-table"
            data-animate="true"
            className="grid grid-cols-1 md:grid-cols-2 gap-10 transition-all duration-700 transform"
            style={{
              opacity: isIntersecting['comparison-table'] ? '1' : '0', 
              transform: isIntersecting['comparison-table'] ? 'translateY(0)' : 'translateY(10px)'
            }}
          >
            <div className="bg-gray-100 p-8 rounded-2xl border border-gray-200">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-gray-700 mb-1">Antes</h3>
                <p className="text-gray-500">Correção manual tradicional</p>
              </div>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-red-100 text-red-600 flex items-center justify-center mr-3 mt-0.5">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <line x1="18" y1="6" x2="6" y2="18"></line>
                      <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                  </span>
                  <span className="text-gray-700">15-20 minutos por redação</span>
                </li>
                <li className="flex items-start">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-red-100 text-red-600 flex items-center justify-center mr-3 mt-0.5">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <line x1="18" y1="6" x2="6" y2="18"></line>
                      <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                  </span>
                  <span className="text-gray-700">Inconsistência entre avaliadores</span>
                </li>
                <li className="flex items-start">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-red-100 text-red-600 flex items-center justify-center mr-3 mt-0.5">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <line x1="18" y1="6" x2="6" y2="18"></line>
                      <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                  </span>
                  <span className="text-gray-700">Comentários limitados por tempo</span>
                </li>
                <li className="flex items-start">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-red-100 text-red-600 flex items-center justify-center mr-3 mt-0.5">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <line x1="18" y1="6" x2="6" y2="18"></line>
                      <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                  </span>
                  <span className="text-gray-700">Sem análises estatísticas</span>
                </li>
                <li className="flex items-start">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-red-100 text-red-600 flex items-center justify-center mr-3 mt-0.5">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <line x1="18" y1="6" x2="6" y2="18"></line>
                      <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                  </span>
                  <span className="text-gray-700">Formatação trabalhosa dos resultados</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-nota-blue p-8 rounded-2xl text-white shadow-xl relative z-10 transform md:translate-y-4">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-nota-green text-white text-xs px-4 py-1 rounded-full font-medium">
                RECOMENDADO
              </div>
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold mb-1">Depois</h3>
                <p className="text-white/70">Com Nota1000.AI</p>
              </div>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-white/20 text-white flex items-center justify-center mr-3 mt-0.5">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                  </span>
                  <span className="text-white">30 segundos por redação</span>
                </li>
                <li className="flex items-start">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-white/20 text-white flex items-center justify-center mr-3 mt-0.5">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                  </span>
                  <span className="text-white">Padronização total nos critérios</span>
                </li>
                <li className="flex items-start">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-white/20 text-white flex items-center justify-center mr-3 mt-0.5">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                  </span>
                  <span className="text-white">Análise detalhada com sugestões</span>
                </li>
                <li className="flex items-start">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-white/20 text-white flex items-center justify-center mr-3 mt-0.5">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                  </span>
                  <span className="text-white">Gráficos de progresso e estatísticas</span>
                </li>
                <li className="flex items-start">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-white/20 text-white flex items-center justify-center mr-3 mt-0.5">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                  </span>
                  <span className="text-white">Exportação automática em PDF</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
      
      {/* Testimonials Section */}
      <section className="py-24 px-6 bg-gray-50">
        <div className="container mx-auto max-w-6xl">
          <div 
            id="testimonials-heading"
            data-animate="true"
            className="text-center max-w-3xl mx-auto mb-16 transition-all duration-700 transform"
            style={{
              opacity: isIntersecting['testimonials-heading'] ? '1' : '0', 
              transform: isIntersecting['testimonials-heading'] ? 'translateY(0)' : 'translateY(10px)'
            }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              O que dizem nossos <span className="text-nota-blue">professores</span>
            </h2>
            <p className="text-xl text-gray-600 leading-relaxed">
              Centenas de educadores já transformaram seus processos de correção com o Nota1000.AI.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div 
                key={index}
                id={`testimonial-${index}`}
                data-animate="true"
                className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 transition-all duration-700 transform"
                style={{
                  opacity: isIntersecting[`testimonial-${index}`] ? '1' : '0', 
                  transform: isIntersecting[`testimonial-${index}`] ? 'translateY(0)' : 'translateY(10px)',
                  transitionDelay: `${index * 100}ms`
                }}
              >
                <div className="mb-6">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} className="inline-block w-5 h-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                    </svg>
                  ))}
                </div>
                
                <p className="text-gray-700 leading-relaxed mb-6">"{testimonial.text}"</p>
                
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-nota-blue/10 rounded-full flex items-center justify-center text-nota-blue font-bold text-lg">
                    {testimonial.name.charAt(0)}
                  </div>
                  <div className="ml-4">
                    <p className="font-medium text-gray-900">{testimonial.name}</p>
                    <p className="text-sm text-gray-500">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-24 px-6">
        <div className="container mx-auto max-w-6xl">
          <div 
            id="cta-section"
            data-animate="true"
            className="bg-nota-blue rounded-3xl overflow-hidden relative transition-all duration-700 transform"
            style={{
              opacity: isIntersecting['cta-section'] ? '1' : '0', 
              transform: isIntersecting['cta-section'] ? 'translateY(0)' : 'translateY(10px)'
            }}
          >
            {/* Background pattern */}
            <div className="absolute inset-0 overflow-hidden">
              <div className="absolute -right-10 top-20 w-80 h-80 rounded-full bg-white/5"></div>
              <div className="absolute left-20 bottom-40 w-60 h-60 rounded-full bg-white/10"></div>
            </div>
            
            <div className="relative p-12 md:p-16 text-white text-center max-w-3xl mx-auto">
              <div className="inline-block bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-medium mb-6">
                🚀 Mais de 5.000 redações corrigidas
              </div>
              
              <h2 className="text-3xl sm:text-4xl font-bold mb-6">
                Comece a corrigir redações com IA hoje mesmo
              </h2>
              
              <p className="text-xl text-white/80 mb-10">
                Experimente gratuitamente e descubra como o Nota1000.AI pode revolucionar seu processo de correção de redações.
              </p>
              
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Button 
                  asChild 
                  className="bg-white text-nota-blue hover:bg-white/90 text-lg px-8 py-6 rounded-xl font-medium shadow-lg transition-all"
                >
                  <Link to="/signup">
                    Criar conta grátis
                  </Link>
                </Button>
                
                <Button 
                  variant="outline" 
                  className="bg-transparent border-white text-white hover:bg-white/10 text-lg px-8 py-6 rounded-xl font-medium transition-all"
                >
                  Agendar demonstração
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* FAQ Section */}
      <section className="py-24 px-6 bg-gray-50" id="faq">
        <div className="container mx-auto max-w-4xl">
          <div 
            id="faq-heading"
            data-animate="true"
            className="text-center mb-16 transition-all duration-700 transform"
            style={{
              opacity: isIntersecting['faq-heading'] ? '1' : '0', 
              transform: isIntersecting['faq-heading'] ? 'translateY(0)' : 'translateY(10px)'
            }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              Perguntas Frequentes
            </h2>
            <p className="text-xl text-gray-600">
              Tudo o que você precisa saber sobre o Nota1000.AI
            </p>
          </div>
          
          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <div 
                key={index}
                id={`faq-item-${index}`}
                data-animate="true"
                className="transition-all duration-700 transform"
                style={{
                  opacity: isIntersecting[`faq-item-${index}`] ? '1' : '0', 
                  transform: isIntersecting[`faq-item-${index}`] ? 'translateY(0)' : 'translateY(10px)',
                  transitionDelay: `${index * 100}ms`
                }}
              >
                <Collapsible>
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                    <CollapsibleTrigger className="flex w-full items-center justify-between p-6 text-left">
                      <h3 className="text-lg font-medium text-gray-900">{faq.question}</h3>
                      <div className="ml-2 flex-shrink-0">
                        <ChevronDown className="h-5 w-5 text-gray-500 ui-open:hidden" />
                        <ChevronUp className="h-5 w-5 text-gray-500 hidden ui-open:block" />
                      </div>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <div className="px-6 pb-6 pt-2 text-gray-600">
                        {faq.answer}
                      </div>
                    </CollapsibleContent>
                  </div>
                </Collapsible>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Footer with lead capture */}
      <footer className="bg-gray-900 text-white py-16 px-6">
        <div className="container mx-auto max-w-6xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="md:col-span-1">
              <div className="flex items-center mb-6">
                <FileText className="h-8 w-8 mr-3 text-nota-blue" />
                <span className="text-2xl font-bold">Nota1000.AI</span>
              </div>
              <p className="text-gray-400 mb-6">
                Plataforma de correção automatizada de redações com IA para professores, escolas e cursos pré-vestibular.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="bg-gray-800 p-2 rounded-full hover:bg-gray-700 transition-colors">
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path fillRule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clipRule="evenodd" />
                  </svg>
                </a>
                <a href="#" className="bg-gray-800 p-2 rounded-full hover:bg-gray-700 transition-colors">
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                  </svg>
                </a>
                <a href="#" className="bg-gray-800 p-2 rounded-full hover:bg-gray-700 transition-colors">
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path fillRule="evenodd" d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 015.45 2.525c.636-.247 1.363-.416 2.427-.465C8.901 2.013 9.256 2 11.685 2h.63zm-.081 1.802h-.468c-2.456 0-2.784.011-3.807.058-.975.045-1.504.207-1.857.344-.467.182-.8.398-1.15.748-.35.35-.566.683-.748 1.15-.137.353-.3.882-.344 1.857-.047 1.023-.058 1.351-.058 3.807v.468c0 2.456.011 2.784.058 3.807.045.975.207 1.504.344 1.857.182.466.399.8.748 1.15.35.35.683.566 1.15.748.353.137.882.3 1.857.344 1.054.048 1.37.058 4.041.058h.08c2.597 0 2.917-.01 3.96-.058.976-.045 1.505-.207 1.858-.344.466-.182.8-.398 1.15-.748.35-.35.566-.683.748-1.15.137-.353.3-.882.344-1.857.048-1.055.058-1.37.058-4.041v-.08c0-2.597-.01-2.917-.058-3.96-.045-.976-.207-1.505-.344-1.858a3.097 3.097 0 00-.748-1.15 3.098 3.098 0 00-1.15-.748c-.353-.137-.882-.3-1.857-.344-1.023-.047-1.351-.058-3.807-.058zM12 6.865a5.135 5.135 0 110 10.27 5.135 5.135 0 010-10.27zm0 1.802a3.333 3.333 0 100 6.666 3.333 3.333 0 000-6.666zm5.338-3.205a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z" clipRule="evenodd" />
                  </svg>
                </a>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-6">Links Rápidos</h3>
              <ul className="space-y-4">
                <li><a href="#beneficios" className="text-gray-400 hover:text-white transition-colors">Benefícios</a></li>
                <li><a href="#como-funciona" className="text-gray-400 hover:text-white transition-colors">Como Funciona</a></li>
                <li><a href="#faq" className="text-gray-400 hover:text-white transition-colors">FAQ</a></li>
                <li><Link to="/login" className="text-gray-400 hover:text-white transition-colors">Login</Link></li>
                <li><Link to="/signup" className="text-gray-400 hover:text-white transition-colors">Cadastro</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-6">Receba Novidades</h3>
              <p className="text-gray-400 mb-4">Inscreva-se para receber dicas, materiais gratuitos e novidades sobre a plataforma.</p>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="footer-email" className="sr-only">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <Input
                      id="footer-email"
                      type="email"
                      placeholder="Seu melhor email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="bg-gray-800 border-gray-700 w-full pl-10 py-3 rounded-lg focus:ring-nota-blue focus:border-nota-blue text-white placeholder-gray-400"
                      required
                    />
                  </div>
                </div>
                
                <Button 
                  type="submit"
                  className="bg-nota-blue hover:bg-nota-blue-700 w-full py-3 rounded-lg transition-colors"
                >
                  Inscrever-se
                </Button>
              </form>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              &copy; {new Date().getFullYear()} Nota1000.AI. Todos os direitos reservados.
            </p>
            
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white text-sm">Termos</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm">Privacidade</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm">Contato</a>
            </div>
          </div>
          
          <div className="mt-8 flex items-center justify-center space-x-4">
            <div className="flex items-center bg-gray-800 px-4 py-2 rounded-lg">
              <span className="text-xs text-gray-400">IA com tecnologia</span>
              <span className="ml-2 text-xs font-semibold text-white">OpenAI GPT-4</span>
            </div>
            
            <div className="flex items-center bg-gray-800 px-4 py-2 rounded-lg">
              <span className="text-xs text-gray-400">Dados seguros com</span>
              <span className="ml-2 text-xs font-semibold text-white">Supabase</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
