import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/lib/supabaseClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, ArrowLeft } from "lucide-react";
import { toast } from "@/components/ui/use-toast";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import ProtectedRoute from "@/components/auth/ProtectedRoute";

interface Redacao {
  id: string;
  titulo: string;
  created_at: string;
  correcao: {
    id: string;
    nota_total: number;
    nota_c1: number;
    nota_c2: number;
    nota_c3: number;
    nota_c4: number;
    nota_c5: number;
    ajuste_humano: boolean;
  } | null;
}

interface ProgressoData {
  data: string;
  nota: number;
}

interface CompetenciasData {
  competencia: string;
  nota: number;
}

const StudentProgress = () => {
  const navigate = useNavigate();
  const [redacoes, setRedacoes] = useState<Redacao[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [progressoData, setProgressoData] = useState<ProgressoData[]>([]);
  const [competenciasData, setCompetenciasData] = useState<CompetenciasData[]>([]);

  useEffect(() => {
    fetchRedacoes();
  }, []);

  const fetchRedacoes = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Usuário não autenticado");

      const { data, error } = await supabase
        .from("redacoes")
        .select(`
          id,
          titulo,
          created_at,
          correcoes (
            id,
            nota_total,
            nota_c1,
            nota_c2,
            nota_c3,
            nota_c4,
            nota_c5,
            ajuste_humano
          )
        `)
        .eq('usuario_id', user.id)
        .order("created_at", { ascending: true });

      if (error) throw error;

      const redacoesFormatadas = data.map(redacao => ({
        id: redacao.id,
        titulo: redacao.titulo,
        created_at: redacao.created_at,
        correcao: redacao.correcoes?.[0] || null
      }));

      setRedacoes(redacoesFormatadas);

      // Preparar dados para o gráfico de progresso
      const progresso = redacoesFormatadas
        .filter(r => r.correcao?.nota_total)
        .map(r => ({
          data: new Date(r.created_at).toLocaleDateString(),
          nota: r.correcao?.nota_total || 0
        }));

      setProgressoData(progresso);

      // Preparar dados para o radar de competências
      if (redacoesFormatadas.length > 0) {
        const ultimaRedacao = redacoesFormatadas[redacoesFormatadas.length - 1];
        if (ultimaRedacao.correcao) {
          const competencias = [
            { competencia: "C1", nota: ultimaRedacao.correcao.nota_c1 },
            { competencia: "C2", nota: ultimaRedacao.correcao.nota_c2 },
            { competencia: "C3", nota: ultimaRedacao.correcao.nota_c3 },
            { competencia: "C4", nota: ultimaRedacao.correcao.nota_c4 },
            { competencia: "C5", nota: ultimaRedacao.correcao.nota_c5 }
          ];
          setCompetenciasData(competencias);
        }
      }

    } catch (error: any) {
      setError(error.message);
      toast({
        title: "Erro ao carregar dados",
        description: "Não foi possível carregar os dados de progresso.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-nota-blue" />
      </div>
    );
  }

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              onClick={() => navigate(-1)}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Voltar
            </Button>
            <h1 className="text-2xl font-bold">Meu Progresso</h1>
          </div>

          {error ? (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          ) : (
            <div className="grid gap-6">
              {/* Gráfico de Progresso */}
              <Card>
                <CardHeader>
                  <CardTitle>Evolução das Notas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={progressoData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="data" />
                        <YAxis domain={[0, 1000]} />
                        <Tooltip />
                        <Line
                          type="monotone"
                          dataKey="nota"
                          stroke="#2563eb"
                          strokeWidth={2}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Radar de Competências */}
              {competenciasData.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Competências</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <RadarChart data={competenciasData}>
                          <PolarGrid />
                          <PolarAngleAxis dataKey="competencia" />
                          <PolarRadiusAxis domain={[0, 200]} />
                          <Radar
                            name="Notas"
                            dataKey="nota"
                            stroke="#2563eb"
                            fill="#2563eb"
                            fillOpacity={0.3}
                          />
                        </RadarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Lista de Redações */}
              <Card>
                <CardHeader>
                  <CardTitle>Histórico de Redações</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {redacoes.map((redacao) => (
                      <div
                        key={redacao.id}
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
                      >
                        <div>
                          <h3 className="font-medium">{redacao.titulo}</h3>
                          <p className="text-sm text-gray-500">
                            {new Date(redacao.created_at).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex items-center gap-4">
                          {redacao.correcao ? (
                            <>
                              <span className="text-lg font-semibold text-nota-blue">
                                {redacao.correcao.nota_total.toFixed(1)}
                              </span>
                              <Button
                                variant="ghost"
                                onClick={() => navigate(`/resultado/${redacao.correcao.id}`)}
                              >
                                Ver Detalhes
                              </Button>
                            </>
                          ) : (
                            <span className="text-sm text-gray-500">Em correção</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </ProtectedRoute>
  );
};

export default StudentProgress; 