
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Plus, FileText, TrendingUp, BarChart3 } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";

// Simulated recent essays data
const recentEssays = [
  { id: 1, title: 'O impacto das redes sociais na sociedade', date: '2023-05-02', type: 'ENEM', score: 920 },
  { id: 2, title: 'Desafios da educação no século XXI', date: '2023-04-28', type: 'Vestibular', score: 880 },
  { id: 3, title: 'Sustentabilidade e consumo consciente', date: '2023-04-20', type: 'ENEM', score: 900 },
];

// Daily tip content
const dailyTip = {
  title: "Dica do dia: Coesão textual",
  content: "Use conectivos adequados entre parágrafos para garantir a fluidez das ideias e fortalecer sua argumentação."
};

const Index = () => {
  const { toast } = useToast();
  
  // Mock user data - would come from authentication context in a real app
  const userName = "José";

  return (
    <div className="container mx-auto max-w-6xl py-8 animate-fade-in">
      <section className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Bem-vindo, {userName}!</h1>
            <p className="text-gray-600">Continue melhorando suas redações com o Nota1000.AI</p>
          </div>
          <Button 
            asChild 
            className="mt-4 md:mt-0 bg-nota-blue hover:bg-nota-blue-700"
            size="lg"
          >
            <Link to="/new" className="flex items-center">
              <Plus className="mr-2 h-5 w-5" />
              Nova Redação
            </Link>
          </Button>
        </div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="mr-2 h-5 w-5" /> 
                Redações Recentes
              </CardTitle>
              <CardDescription>Suas últimas redações enviadas para correção</CardDescription>
            </CardHeader>
            <CardContent>
              {recentEssays.length > 0 ? (
                <div className="space-y-4">
                  {recentEssays.map((essay) => (
                    <Link 
                      to={`/essay/${essay.id}`} 
                      key={essay.id}
                      className="block"
                    >
                      <div className="border rounded-lg p-4 hover:border-nota-blue hover:bg-blue-50 transition-all">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-medium text-gray-900">{essay.title}</h3>
                            <div className="flex items-center mt-1 text-sm text-gray-500">
                              <span>{new Date(essay.date).toLocaleDateString('pt-BR')}</span>
                              <span className="mx-2">•</span>
                              <span>{essay.type}</span>
                            </div>
                          </div>
                          <div className="bg-gray-100 text-nota-blue font-semibold rounded-full px-3 py-1 text-sm">
                            {essay.score}
                          </div>
                        </div>
                      </div>
                    </Link>
                  ))}
                  
                  <div className="text-center pt-2">
                    <Button variant="outline" asChild>
                      <Link to="/history">Ver todas as redações</Link>
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-6">
                  <FileText className="mx-auto h-12 w-12 text-gray-300" />
                  <h3 className="mt-2 text-sm font-semibold text-gray-900">Nenhuma redação ainda</h3>
                  <p className="mt-1 text-sm text-gray-500">
                    Você ainda não enviou redações para correção.
                  </p>
                  <div className="mt-6">
                    <Button asChild>
                      <Link to="/new">Criar minha primeira redação</Link>
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="mr-2 h-5 w-5" />
                Seu Progresso
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-6">
                <BarChart3 className="mx-auto h-12 w-12 text-gray-300" />
                <h3 className="mt-2 text-sm font-semibold text-gray-900">Progresso em breve</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Continue enviando redações para ver seu progresso ao longo do tempo.
                </p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>{dailyTip.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">{dailyTip.content}</p>
              <Button 
                variant="link" 
                className="p-0 mt-2 text-nota-blue" 
                onClick={() => {
                  toast({
                    title: "Dica salva!",
                    description: "Esta dica foi salva em seu perfil.",
                  })
                }}
              >
                Salvar dica
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Index;
