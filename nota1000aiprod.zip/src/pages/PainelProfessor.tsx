import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/lib/supabaseClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, FileText, Users, Star, ArrowRight, Edit2 } from "lucide-react";
import { toast } from "@/components/ui/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import ProtectedProfessorRoute from "@/components/auth/ProtectedProfessorRoute";
import { Checkbox } from "@/components/ui/checkbox";
import { JSZip } from "jszip";
import { saveAs } from "file-saver";
import { PDFDocument, rgb } from "pdf-lib";

interface Redacao {
  id: string;
  titulo: string;
  created_at: string;
  usuario: {
    nome: string;
    email: string;
  };
  correcao: {
    id: string;
    nota_total: number;
    nota_c1: number;
    nota_c2: number;
    nota_c3: number;
    nota_c4: number;
    nota_c5: number;
    ajuste_humano: boolean;
  } | null;
}

interface AjusteHumano {
  nota_c1: number;
  nota_c2: number;
  nota_c3: number;
  nota_c4: number;
  nota_c5: number;
  nota_total: number;
  feedback: string;
}

const PainelProfessor = () => {
  const navigate = useNavigate();
  const [redacoes, setRedacoes] = useState<Redacao[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedRedacao, setSelectedRedacao] = useState<Redacao | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedRedacoes, setSelectedRedacoes] = useState<string[]>([]);
  const [ajuste, setAjuste] = useState<AjusteHumano>({
    nota_c1: 0,
    nota_c2: 0,
    nota_c3: 0,
    nota_c4: 0,
    nota_c5: 0,
    nota_total: 0,
    feedback: ""
  });

  useEffect(() => {
    fetchRedacoes();
  }, []);

  const fetchRedacoes = async () => {
    try {
      const { data, error } = await supabase
        .from("redacoes")
        .select(`
          id,
          titulo,
          created_at,
          usuario:usuarios (
            nome,
            email
          ),
          correcoes (
            id,
            nota_total,
            nota_c1,
            nota_c2,
            nota_c3,
            nota_c4,
            nota_c5,
            ajuste_humano
          )
        `)
        .order("created_at", { ascending: false });

      if (error) throw error;

      const redacoesFormatadas = data.map(redacao => ({
        id: redacao.id,
        titulo: redacao.titulo,
        created_at: redacao.created_at,
        usuario: {
          nome: redacao.usuario[0]?.nome || '',
          email: redacao.usuario[0]?.email || ''
        },
        correcao: redacao.correcoes?.[0] || null
      }));

      setRedacoes(redacoesFormatadas);
    } catch (error: any) {
      setError(error.message);
      toast({
        title: "Erro ao carregar redações",
        description: "Não foi possível carregar as redações. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAjusteChange = (field: keyof AjusteHumano, value: string | number) => {
    setAjuste(prev => {
      const newAjuste = { ...prev, [field]: value };
      
      // Recalcular nota total se alguma nota de competência mudar
      if (field.startsWith('nota_c')) {
        const notas = [
          newAjuste.nota_c1,
          newAjuste.nota_c2,
          newAjuste.nota_c3,
          newAjuste.nota_c4,
          newAjuste.nota_c5
        ];
        newAjuste.nota_total = Number((notas.reduce((a, b) => a + b, 0) / 5).toFixed(1));
      }
      
      return newAjuste;
    });
  };

  const handleSaveAjuste = async () => {
    if (!selectedRedacao?.correcao?.id) return;

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Usuário não autenticado");

      // Criar ou atualizar ajuste humano
      const { error: ajusteError } = await supabase
        .from('ajustes_humanos')
        .upsert({
          correcao_id: selectedRedacao.correcao.id,
          professor_id: user.id,
          ...ajuste
        });

      if (ajusteError) throw ajusteError;

      // Atualizar flag de ajuste humano na correção
      const { error: correcaoError } = await supabase
        .from('correcoes')
        .update({ ajuste_humano: true })
        .eq('id', selectedRedacao.correcao.id);

      if (correcaoError) throw correcaoError;

      toast({
        title: "Ajuste salvo",
        description: "O ajuste manual foi salvo com sucesso.",
      });

      setIsEditing(false);
      fetchRedacoes();
    } catch (error: any) {
      toast({
        title: "Erro ao salvar ajuste",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleExportSelected = async () => {
    try {
      const zip = new JSZip();
      
      for (const redacaoId of selectedRedacoes) {
        const redacao = redacoes.find(r => r.id === redacaoId);
        if (!redacao?.correcao) continue;

        // Criar PDF
        const pdfDoc = await PDFDocument.create();
        const page = pdfDoc.addPage();
        const { width, height } = page.getSize();
        
        // Adicionar conteúdo ao PDF
        page.drawText(`Redação: ${redacao.titulo}`, {
          x: 50,
          y: height - 50,
          size: 20,
          color: rgb(0, 0, 0),
        });

        page.drawText(`Aluno: ${redacao.usuario.nome}`, {
          x: 50,
          y: height - 80,
          size: 12,
          color: rgb(0, 0, 0),
        });

        page.drawText(`Nota Total: ${redacao.correcao.nota_total}`, {
          x: 50,
          y: height - 100,
          size: 12,
          color: rgb(0, 0, 0),
        });

        // Salvar PDF no ZIP
        const pdfBytes = await pdfDoc.save();
        zip.file(`${redacao.titulo}.pdf`, pdfBytes);
      }

      // Gerar e baixar ZIP
      const content = await zip.generateAsync({ type: "blob" });
      saveAs(content, "redacoes.zip");

      toast({
        title: "Exportação concluída",
        description: "As redações foram exportadas com sucesso.",
      });
    } catch (error: any) {
      toast({
        title: "Erro na exportação",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  return (
    <ProtectedProfessorRoute>
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold">Painel do Professor</h1>
            <div className="flex items-center gap-4">
              <Button
                variant="outline"
                onClick={() => navigate("/profile")}
                className="flex items-center gap-2"
              >
                <Users className="h-4 w-4" />
                Meus Alunos
              </Button>
              {selectedRedacoes.length > 0 && (
                <Button
                  onClick={handleExportSelected}
                  className="flex items-center gap-2"
                >
                  <FileText className="h-4 w-4" />
                  Exportar Selecionadas ({selectedRedacoes.length})
                </Button>
              )}
            </div>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-nota-blue" />
            </div>
          ) : error ? (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          ) : redacoes.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  Nenhuma redação encontrada
                </h3>
                <p className="text-gray-500">
                  Ainda não há redações para corrigir.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {redacoes.map((redacao) => (
                <Card key={redacao.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4">
                        <Checkbox
                          checked={selectedRedacoes.includes(redacao.id)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedRedacoes([...selectedRedacoes, redacao.id]);
                            } else {
                              setSelectedRedacoes(selectedRedacoes.filter(id => id !== redacao.id));
                            }
                          }}
                        />
                        <div className="space-y-1">
                          <CardTitle className="text-lg font-semibold">
                            {redacao.titulo}
                          </CardTitle>
                          <div className="text-sm text-gray-500">
                            <p>Aluno: {redacao.usuario.nome}</p>
                            <p>Email: {redacao.usuario.email}</p>
                            <p>Data: {formatDate(redacao.created_at)}</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-4">
                        {redacao.correcao ? (
                          <div className="flex items-center text-nota-blue">
                            <Star className="h-5 w-5 mr-1" />
                            <span className="font-semibold">
                              {redacao.correcao.nota_total.toFixed(1)}
                            </span>
                            {redacao.correcao.ajuste_humano && (
                              <span className="ml-2 text-xs text-gray-500">(Ajuste Manual)</span>
                            )}
                          </div>
                        ) : (
                          <span className="text-sm text-gray-500">Em correção</span>
                        )}
                        
                        <Button
                          variant="ghost"
                          onClick={() => navigate(`/resultado/${redacao.correcao?.id}`)}
                          className="flex items-center gap-2"
                        >
                          Ver resultado
                          <ArrowRight className="h-4 w-4" />
                        </Button>

                        {redacao.correcao && (
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  setSelectedRedacao(redacao);
                                  setIsEditing(true);
                                  setAjuste({
                                    nota_c1: redacao.correcao?.nota_c1 || 0,
                                    nota_c2: redacao.correcao?.nota_c2 || 0,
                                    nota_c3: redacao.correcao?.nota_c3 || 0,
                                    nota_c4: redacao.correcao?.nota_c4 || 0,
                                    nota_c5: redacao.correcao?.nota_c5 || 0,
                                    nota_total: redacao.correcao?.nota_total || 0,
                                    feedback: ""
                                  });
                                }}
                              >
                                <Edit2 className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-2xl">
                              <DialogHeader>
                                <DialogTitle>Ajuste Manual</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <Label htmlFor="nota_c1">Competência 1</Label>
                                    <Input
                                      id="nota_c1"
                                      type="number"
                                      min="0"
                                      max="200"
                                      value={ajuste.nota_c1}
                                      onChange={(e) => handleAjusteChange('nota_c1', Number(e.target.value))}
                                    />
                                  </div>
                                  <div>
                                    <Label htmlFor="nota_c2">Competência 2</Label>
                                    <Input
                                      id="nota_c2"
                                      type="number"
                                      min="0"
                                      max="200"
                                      value={ajuste.nota_c2}
                                      onChange={(e) => handleAjusteChange('nota_c2', Number(e.target.value))}
                                    />
                                  </div>
                                  <div>
                                    <Label htmlFor="nota_c3">Competência 3</Label>
                                    <Input
                                      id="nota_c3"
                                      type="number"
                                      min="0"
                                      max="200"
                                      value={ajuste.nota_c3}
                                      onChange={(e) => handleAjusteChange('nota_c3', Number(e.target.value))}
                                    />
                                  </div>
                                  <div>
                                    <Label htmlFor="nota_c4">Competência 4</Label>
                                    <Input
                                      id="nota_c4"
                                      type="number"
                                      min="0"
                                      max="200"
                                      value={ajuste.nota_c4}
                                      onChange={(e) => handleAjusteChange('nota_c4', Number(e.target.value))}
                                    />
                                  </div>
                                  <div>
                                    <Label htmlFor="nota_c5">Competência 5</Label>
                                    <Input
                                      id="nota_c5"
                                      type="number"
                                      min="0"
                                      max="200"
                                      value={ajuste.nota_c5}
                                      onChange={(e) => handleAjusteChange('nota_c5', Number(e.target.value))}
                                    />
                                  </div>
                                  <div>
                                    <Label htmlFor="nota_total">Nota Total</Label>
                                    <Input
                                      id="nota_total"
                                      type="number"
                                      min="0"
                                      max="1000"
                                      step="0.1"
                                      value={ajuste.nota_total}
                                      onChange={(e) => handleAjusteChange('nota_total', Number(e.target.value))}
                                    />
                                  </div>
                                </div>
                                <div>
                                  <Label htmlFor="feedback">Feedback</Label>
                                  <Textarea
                                    id="feedback"
                                    value={ajuste.feedback}
                                    onChange={(e) => handleAjusteChange('feedback', e.target.value)}
                                    rows={4}
                                  />
                                </div>
                                <Button onClick={handleSaveAjuste}>
                                  Salvar Ajuste
                                </Button>
                              </div>
                            </DialogContent>
                          </Dialog>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </ProtectedProfessorRoute>
  );
};

export default PainelProfessor; 